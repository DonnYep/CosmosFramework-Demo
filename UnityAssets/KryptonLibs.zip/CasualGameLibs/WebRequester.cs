﻿using UnityEngine.Networking;
namespace Krypton.CasualGame
{
    public class WebRequester
    {
        /// <summary>
        /// 生成请求头部信息；
        /// </summary>
        /// <param name="url">不包含https://或者http://的请求地址</param>
        /// <param name="token">token</param>
        /// <param name="signSecret">密钥</param>
        /// <returns>头部信息</returns>
        public static Header[] GenerateHeader(string url, string token, string signSecret)
        {
            var headers = new Header[5];
            var tsHeader = new Header("x-k7-timestamp", Utility.Time.SecondTimeStamp().ToString());
            var nonceHeader = new Header("x-k7-nonce", Utility.Algorithm.RandomRange(0, int.MaxValue).ToString());
            var tokenHeader = new Header("x-k7-token", token);
            var signValue = $"{url}&x-k7-timestamp={tsHeader.value}&x-k7-nonce={nonceHeader.value}&x-k7-token={tokenHeader.value}";
            var sha256 = Utility.Encryption.HmacSHA256(signValue, signSecret);
            var signHeader = new Header("x-k7-sign", sha256);
            var contentHeader = new Header("Content-Type", "application/json");
            headers[0] = tsHeader;
            headers[1] = nonceHeader;
            headers[2] = tokenHeader;
            headers[3] = signHeader;
            headers[4] = contentHeader;
            return headers;
        }
        public static UnityWebRequest CreatePutRequest(string url, byte[] bodyData, params Header[] headers)
        {
            UnityWebRequest unityWebRequest = UnityWebRequest.Put(url, bodyData);
            var headerLength = headers.Length;
            for (int i = 0; i < headerLength; i++)
            {
                var header = headers[i];
                unityWebRequest.SetRequestHeader(header.name, header.value);
            }
            return unityWebRequest;
        }
        public static UnityWebRequest CreatePutRequest(string url, string bodyData, params Header[] headers)
        {
            UnityWebRequest unityWebRequest = UnityWebRequest.Put(url, bodyData);
            var headerLength = headers.Length;
            for (int i = 0; i < headerLength; i++)
            {
                var header = headers[i];
                unityWebRequest.SetRequestHeader(header.name, header.value);
            }
            return unityWebRequest;
        }
        public static UnityWebRequest CreateGetRequest(string url, params Header[] headers)
        {
            UnityWebRequest unityWebRequest = UnityWebRequest.Get(url);
            unityWebRequest.downloadHandler = new DownloadHandlerBuffer();
            var headerLength = headers.Length;
            for (int i = 0; i < headerLength; i++)
            {
                var header = headers[i];
                unityWebRequest.SetRequestHeader(header.name, header.value);
            }
            return unityWebRequest;
        }
    }
}
