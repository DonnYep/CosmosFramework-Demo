namespace Krypton.CasualGame
{
    public class CasualGameConstants
    {
        /// <summary>
        /// 测试环境host；
        /// </summary>
        public const string DEV_HOST = "http://dev-casualgame-gw.svc.qipai007cs.com/";
        /// <summary>
        /// 测试环境sign拼接头部信息；
        /// </summary>
        public const string DEV_SIGN = "dev-casualgame-gw.svc.qipai007cs.com/";
        /// <summary>
        /// 测试环境token。token会过期，kaiqi内网环境是一天，测试需要向后端支持索要最新token；
        /// </summary>
        public static string DevToken = "ffb032807a77c9b4cc2496a197eaf4a1dd22a1ca";
        /// <summary>
        /// 测试环境网关密钥
        /// </summary>
        public const string DEV_SIGN_SECRET = "casualgame-gw-signature-secret";
        /// <summary>
        /// 生产环境地址；
        /// </summary>
        public const string PROD_HOST = "https://casualgame-slb.yeetown.cc";

        public const string PROD_SIGN_SECRET = "SWXmH30QKLHpGwNBamOCphjG";

        public const string PROD_TEST_TOKEN= "04b84cd488a3434836d0dd988e94839fa06c69f6";
        public const string TEST_USER_ID= "10075354";
    }
}
