﻿using System;
namespace Krypton.CasualGame
{
    public struct Header : IEquatable<Header>
    {
        public string name;
        public string value;
        public Header(string name, string value)
        {
            this.name = name;
            this.value = value;
        }
        public bool Equals(Header other)
        {
            return name == other.name && value == other.value;
        }
    }
}
