﻿using System;

namespace Krypton.CasualGame
{
    /// <summary>
    /// 微服务返回的数据结构；
    /// </summary>
    [Serializable]
    public class RspData<DATA>
        where DATA : IData
    {
        public uint code;
        public string msg;
        public DATA data;
    }
}
