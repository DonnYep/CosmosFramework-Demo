﻿namespace Krypton.CasualGame
{
    public interface IData
    {
    }
}
