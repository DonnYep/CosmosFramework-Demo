﻿using System;

namespace Krypton.CasualGame
{
    /// <summary>
    /// 微服务向服务器发送的数据结构； 
    /// </summary>
    [Serializable]
    public class ReqData<QUERY, BODY>
        where QUERY : IQueryData
        where BODY : IBodyData
    {
        public QUERY query;
        public BODY body;
    }
}
