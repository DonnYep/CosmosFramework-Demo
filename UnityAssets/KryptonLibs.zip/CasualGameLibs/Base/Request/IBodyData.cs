﻿namespace Krypton.CasualGame
{
    public interface IBodyData
    {
    }
}
