﻿namespace Krypton.CasualGame
{
    public interface IQueryData
    {
    }
}
