﻿namespace Krypton.CasualGame
{
    public class HeaderGenerator
    {
        /// <summary>
        /// 生成默认请求头部信息；
        /// </summary>
        /// <param name="url">不包含https://或者http://的请求地址</param>
        /// <param name="token">token</param>
        /// <param name="signSecret">密钥</param>
        /// <returns>头部信息</returns>
        public static Header[] GenerateHeader(string url, string token, string signSecret)
        {
            var headers = new Header[5];
            var tsHeader = new Header("x-k7-timestamp", Utility.Time.SecondTimeStamp().ToString());
            var nonceHeader = new Header("x-k7-nonce", Utility.Algorithm.RandomRange(0, int.MaxValue).ToString());
            var tokenHeader = new Header("x-k7-token", token);
            var signValue = $"{url}&x-k7-timestamp={tsHeader.value}&x-k7-nonce={nonceHeader.value}&x-k7-token={tokenHeader.value}";
            var sha256 = Utility.Encryption.HmacSHA256(signValue, signSecret);
            var signHeader = new Header("x-k7-sign", sha256);
            var contentHeader = new Header("Content-Type", "application/json");
            headers[0] = tsHeader;
            headers[1] = nonceHeader;
            headers[2] = tokenHeader;
            headers[3] = signHeader;
            headers[4] = contentHeader;
            return headers;
        }
    }
}
