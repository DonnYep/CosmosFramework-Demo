﻿namespace Krypton.CasualGame
{
    public class SystemTimeHost
    {
        /// <summary>
        /// 接口地址；
        /// Mock地址：http://yapi.kaiqitech.com/mock/247/casualgame/sys/time
        /// </summary>
        public const string Url = "casualgame/sys/time";
    }
}
