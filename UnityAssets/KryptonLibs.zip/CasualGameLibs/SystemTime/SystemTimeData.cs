﻿namespace Krypton.CasualGame
{
    public class SystemTimeData:IData
    {
        public long timestamp;
    }
}
