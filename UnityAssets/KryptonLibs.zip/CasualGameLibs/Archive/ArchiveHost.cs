﻿namespace Krypton.CasualGame
{
    public class ArchiveHost
    {
        /// <summary>
        /// 接口地址；
        /// Mock地址：http://yapi.kaiqitech.com/mock/247/casualgame/archive
        /// </summary>
        public const string Url = "casualgame/archive";
    }
}
