﻿using System;

namespace Krypton.CasualGame
{
    /// <summary>
    /// 存档数据体；
    /// </summary>
    [Serializable]
    public class ArchiveData:IData
    {
        public string user_id;
        public string app_id;
        /// <summary>
        /// base64字符
        /// </summary>
        public string archive;
        public string update_time;
    }
}
