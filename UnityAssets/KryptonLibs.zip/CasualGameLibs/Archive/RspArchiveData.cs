﻿using System;

namespace Krypton.CasualGame
{
    [Serializable]
    public class RspArchiveData
    {
        public int update_time;
    }
}
