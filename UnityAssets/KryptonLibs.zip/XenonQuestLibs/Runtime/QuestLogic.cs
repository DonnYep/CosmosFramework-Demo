﻿namespace Krypton.Xenon
{
    public abstract class QuestLogic
    {
        public abstract void OnAccept();
        public abstract void OnActive();
        public abstract void OnProgress();
        public abstract void OnComplete();
        public abstract void OnFailure();
        public abstract void OnAbort();
    }
}
