using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace Krypton.Xenon
{
    /// <summary>
    /// ����ڵ�
    /// </summary>
    public  class QuestNode 
    {
        /// <summary>
        /// unique key for quest node
        /// </summary>
        public int QuestId { get; set; }
        public byte QuestType{ get; set; }
        /// <summary>
        /// quest logic
        /// </summary>
        public QuestLogic QuestLogic;
    }
}
