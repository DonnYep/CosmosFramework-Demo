using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;
using UnityEngine.Events;

namespace MatchTile3D
{
	public class DoTweenHelper
	{
		public static Tweener ToFloat(float start_value, float endValue, float duration, UnityAction<float> unityAction)
		{
			return DOTween.To(() => start_value, (change_value) =>
			{
				unityAction?.Invoke(change_value);
			}, endValue, duration).SetEase(Ease.Linear);
		}

		public static Tweener ToInt(int start_value, int endValue, float duration, UnityAction<int> unityAction)
		{
			return DOTween.To(() => start_value, (change_value) =>
			{
				unityAction?.Invoke(change_value);
			}, endValue, duration).SetEase(Ease.Linear);
		}
		public static Tweener ToInt64(long start_value, long endValue, float duration, UnityAction<long> unityAction)
		{
			return DOTween.To(() => start_value, (change_value) =>
			{
				unityAction?.Invoke(change_value);
			}, endValue, duration).SetEase(Ease.Linear);
		}

		public static Tweener DoTextFade(Text text, float end_value, float timer)
		{
			return text.DOFade(end_value, timer);
		}

		public static Tweener DoSeagullPath(Transform transform, Vector3[] path, float timer)
		{
			return transform.DOPath(path, timer, PathType.CatmullRom, PathMode.Sidescroller2D, 10).SetEase(Ease.Linear).SetLookAt(0.001f);
		}
	}
}


