﻿using System;

namespace Krypton.Editor.Luban
{
    /// <summary>
    /// luban编辑器界面的持久化数据；
    /// </summary>
    [Serializable]
    internal class LubanEditorData
    {

        public int GenLableIndex;

        public int CSBinCodeGenTypeIndex;
        public int CSBinDataGenTypeIndex;
        public string CSBinCodeGenPath;
        public string CSBinDataGenPath;
        public string CSBinBatchFileName;
        public string CSBinBatchFileAbsPath;
        public bool CSBinSyncGen;

        public int CSJsonCodeGenTypeIndex;
        public int CSJsonDataGenTypeIndex;
        public string CSJsonCodeGenPath;
        public string CSJsonDataGenPath;
        public string CSJsonBatchFileName;
        public string CSJsonBatchFileAbsPath;
        public bool CSJsonSyncGen;

        public int LuaBinCodeGenTypeIndex;
        public int LuaBinDataGenTypeIndex;
        public string LuaBinCodeGenPath;
        public string LuaBinDataGenPath;
        public string LuaBinBatchFileName;
        public string LuaBinBatchFileAbsPath;
        public bool LuaBinSyncGen;
    }
}
