﻿namespace Krypton.Editor.Luban
{
    internal class LubanDataProxy
    {
        public static LubanEditorData LubanEditorData { get; set; }
    }
}
