using UnityEngine;
using UnityEditor;
namespace Krypton.Editor.Luban
{
    public class LubanBuildWindow : EditorWindow
    {
        Vector2 scrollPos;
        LubanEditorData lubanEditorData;
        LubanEditorData LubanEditorData
        {
            get
            {
                return lubanEditorData;
            }
        }
        static LubanBuildWindow lubanBuildWindow;
        const string lubanEditorDataFileName = "LubanEditorData.json";

        GenLable genLable = new GenLable();
        LubanLableBase lubanCSharpBinaryLable = new LubanCSBinLable();
        LubanLableBase lubanCSharpJsonLable = new LubanCSJsonLable();
        LubanLableBase lubanLuaBinaryLable = new LubanLuaBinLable();
        public LubanBuildWindow()
        {
            this.titleContent = new GUIContent("Luban");
        }
        [MenuItem("Window/Krypton/Luban", false, 31)]
        public static void OpenWindow()
        {
            lubanBuildWindow = GetWindow<LubanBuildWindow>();
            ((EditorWindow)lubanBuildWindow).minSize = EditorUtil.DevWinSize;
        }
        void OnEnable()
        {
            try
            {
                lubanEditorData = EditorUtil.GetData<LubanEditorData>(lubanEditorDataFileName);
                LubanDataProxy.LubanEditorData = lubanEditorData;
            }
            catch
            {
                lubanEditorData = new LubanEditorData();
                LubanDataProxy.LubanEditorData = lubanEditorData;
                ResetLables();
                EditorUtil.SaveData(lubanEditorDataFileName, LubanEditorData);
            }
        }
        void OnDisable()
        {
            EditorUtil.SaveData(lubanEditorDataFileName, LubanEditorData);
        }
        void OnGUI()
        {
            scrollPos = EditorGUILayout.BeginScrollView(scrollPos);
            GUILayout.Space(8);
            DrawTitle();
            EditorGUILayout.LabelField("", GUI.skin.horizontalSlider, GUILayout.MaxHeight(4));
            GUILayout.Space(16);
            GUILayout.BeginHorizontal();
            EditorGUILayout.BeginVertical();
            EditorGUILayout.HelpBox("请注意：\"代码生成类型\" 与  \"数据生成类型\" 不可同时为NONE！", MessageType.Warning);
            GUILayout.Space(16);
            EditorGUILayout.BeginHorizontal();
            genLable.OnGUI();
            EditorGUILayout.LabelField("", GUI.skin.verticalSlider, GUILayout.MaxWidth(4), GUILayout.MinHeight(488));
            GUILayout.Space(4);

            EditorGUILayout.BeginHorizontal();
            switch (LubanDataProxy.LubanEditorData.GenLableIndex)
            {
                case 0:
                    lubanCSharpJsonLable.OnGUI();
                    break;
                case 1:
                    lubanCSharpBinaryLable.OnGUI();
                    break;
                case 2:
                    lubanLuaBinaryLable.OnGUI();
                    break;
            }
            EditorGUILayout.EndHorizontal();
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.LabelField("", GUI.skin.horizontalSlider, GUILayout.MaxHeight(4));
            GUILayout.Space(16);
            DrawGenerateLable();
            GUILayout.Space(16);
            EditorGUILayout.EndVertical();
            GUILayout.EndHorizontal();
            EditorGUILayout.EndScrollView();
        }
        void DrawTitle()
        {
            GUIStyle style = new GUIStyle();
            style.fontSize = 24;
            EditorGUILayout.LabelField("配表工具", style);
            GUILayout.Space(16);
            EditorGUILayout.HelpBox("本配表工具采用的开源库为Luban", MessageType.Info);
            GUILayout.Space(8);
            GUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            if (GUILayout.Button("查看Luban文档", GUILayout.MaxWidth(128)))
            {
                Application.OpenURL("https://focus-creative-games.github.io/luban/");
            }
            GUILayout.EndHorizontal();
        }
        void DrawGenerateLable()
        {
            EditorGUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            if (GUILayout.Button("重置所有面板", GUILayout.MaxWidth(128)))
            {
                ResetLables();
                Repaint();
            }
            EditorGUILayout.EndHorizontal();
        }
        void ResetLables()
        {
            lubanCSharpJsonLable.ResetLable();
            lubanCSharpBinaryLable.ResetLable();
            lubanLuaBinaryLable.ResetLable();
        }
    }
}
