﻿using UnityEngine;
namespace Krypton.Editor.Luban
{
    public class GenLable
    {
        string[] genLableArray = new string[] { "Json", "Binary", "Lua" };
        public void OnGUI()
        {
            GUILayout.BeginVertical(GUILayout.MaxWidth(128));
            LubanDataProxy.LubanEditorData.GenLableIndex = GUILayout.SelectionGrid(LubanDataProxy.LubanEditorData.GenLableIndex, genLableArray, 1);
            GUILayout.EndVertical();
        }
    }
}
