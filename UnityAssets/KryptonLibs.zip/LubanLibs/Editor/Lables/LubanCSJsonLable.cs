﻿namespace Krypton.Editor.Luban
{
    public class LubanCSJsonLable : LubanLableBase
    {
        public override string CodeGenPath
        {
            get { return LubanDataProxy.LubanEditorData.CSJsonCodeGenPath; }
            set { LubanDataProxy.LubanEditorData.CSJsonCodeGenPath = value; }
        }
        public override string DataGenPath
        {
            get { return LubanDataProxy.LubanEditorData.CSJsonDataGenPath; }
            set { LubanDataProxy.LubanEditorData.CSJsonDataGenPath = value; }
        }
        public override int DataGenTypeIndex
        {
            get { return LubanDataProxy.LubanEditorData.CSJsonDataGenTypeIndex; }
            set { LubanDataProxy.LubanEditorData.CSJsonDataGenTypeIndex = value; }
        }
        public override int CodeGenTypeIndex
        {
            get { return LubanDataProxy.LubanEditorData.CSJsonCodeGenTypeIndex; }
            set { LubanDataProxy.LubanEditorData.CSJsonCodeGenTypeIndex = value; }
        }
        public override string BatchFileAbsPath
        {
            get { return LubanDataProxy.LubanEditorData.CSJsonBatchFileAbsPath; }
            set { LubanDataProxy.LubanEditorData.CSJsonBatchFileAbsPath = value; }
        }
        public override string[] CodeGenArray
        {
            get { return LableConsts.CodeGenArray; }
        }
        public override string[] DataGenArray
        {
            get { return LableConsts.DataGenArray; }
        }
        public override string[] DataGenSummaryArray
        {
            get { return LableConsts.DataGenSummaryArray; }
        }
        public override string[] CodeGenSummaryArray
        {
            get { return LableConsts.CodeGenSummaryArray; }
        }
        public override string BatName
        {
            get { return LableConsts.BAT_NAME; }
        }
        public override string DefaultCodeGenPath
        {
            get { return LableConsts.DEFAULT_CODE_GEN_PATH; }
        }
        public override string DefaultDataGenPath
        {
            get { return LableConsts.DEFAULT_DATA_GEN_PATH; }
        }
        public override string LableInfo
        {
            get { return "C# Json 生成面板"; }
        }
        public override string LableDataType
        {
            get { return "Json"; }
        }
        public override string LableCodeType
        {
            get { return "C#"; }
        }
        public override bool GenSyncCode
        {
            get { return LubanDataProxy.LubanEditorData.CSJsonSyncGen; }
            set { LubanDataProxy.LubanEditorData.CSJsonSyncGen = value; }
        }
        public override void ResetLable()
        {
            CodeGenPath = LableConsts.DEFAULT_CODE_GEN_PATH;
            DataGenPath = LableConsts.DEFAULT_DATA_GEN_PATH;
            CodeGenTypeIndex = 1;
            DataGenTypeIndex = 1;
        }
        static class LableConsts
        {
            public static string BAT_NAME = @"gen_code_cs_json.bat";
            public const string DEFAULT_CODE_GEN_PATH = @"Assets\Gens\CSJson\Code";
            public const string DEFAULT_DATA_GEN_PATH = @"Assets\Gens\CSJson\Data";
            public static string[] CodeGenArray { get { return codeGenArray; } }
            public static string[] DataGenArray { get { return dataGenArray; } }
            public static string[] CodeGenSummaryArray { get { return codeGenSummaryArray; } }
            public static string[] DataGenSummaryArray { get { return dataGenSummaryArray; } }

            readonly static string[] codeGenArray = new string[]
            {
                "NONE",
                "code_cs_unity_json",
                "code_cs_unity_editor_json",
                "code_cs_dotnet_json"
            };
            static string[] dataGenArray = new string[]
            {
                "NONE",
                "data_json"
            };
            readonly static string[] codeGenSummaryArray = new string[]
            {
                "不生成C#代码",
                "生成适合unity的读取json格式数据的代码",
                "生成适用于unity编辑器开发的代码",
                "生成dotnet平台的读取json格式数据的代码。注意：.NetCore代码无法兼容.NetFramework，在Unity环境请勿使用！"
            };
            static string[] dataGenSummaryArray = new string[]
            {
                "不生成json格式数据",
                "导出json格式数据"
            };
        }
    }
}
