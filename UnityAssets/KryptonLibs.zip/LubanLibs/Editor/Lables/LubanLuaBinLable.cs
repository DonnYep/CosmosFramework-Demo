﻿namespace Krypton.Editor.Luban
{
    public class LubanLuaBinLable : LubanLableBase
    {
        public override string CodeGenPath
        {
            get { return LubanDataProxy.LubanEditorData.LuaBinCodeGenPath; }
            set { LubanDataProxy.LubanEditorData.LuaBinCodeGenPath = value; }
        }
        public override string DataGenPath
        {
            get { return LubanDataProxy.LubanEditorData.LuaBinDataGenPath; }
            set { LubanDataProxy.LubanEditorData.LuaBinDataGenPath = value; }
        }
        public override int DataGenTypeIndex
        {
            get { return LubanDataProxy.LubanEditorData.LuaBinDataGenTypeIndex; }
            set { LubanDataProxy.LubanEditorData.LuaBinDataGenTypeIndex = value; }
        }
        public override int CodeGenTypeIndex
        {
            get { return LubanDataProxy.LubanEditorData.LuaBinCodeGenTypeIndex; }
            set { LubanDataProxy.LubanEditorData.LuaBinCodeGenTypeIndex = value; }
        }
        public override string BatchFileAbsPath
        {
            get { return LubanDataProxy.LubanEditorData.LuaBinBatchFileAbsPath; }
            set { LubanDataProxy.LubanEditorData.LuaBinBatchFileAbsPath = value; }
        }
        public override string[] CodeGenArray
        {
            get { return LableConsts.CodeGenArray; }
        }
        public override string[] DataGenArray
        {
            get { return LableConsts.DataGenArray; }
        }
        public override string[] DataGenSummaryArray
        {
            get { return LableConsts.DataGenSummaryArray; }
        }
        public override string[] CodeGenSummaryArray
        {
            get { return LableConsts.CodeGenSummaryArray; }
        }
        public override string BatName
        {
            get { return LableConsts.BAT_NAME; }
        }
        public override string DefaultCodeGenPath
        {
            get { return LableConsts.DEFAULT_CODE_GEN_PATH; }
        }
        public override string DefaultDataGenPath
        {
            get { return LableConsts.DEFAULT_DATA_GEN_PATH; }
        }
        public override string LableInfo
        {
            get { return "Lua Binary 生成面板"; }
        }
        public override string LableDataType
        {
            get { return "Bin"; }
        }
        public override string LableCodeType
        {
            get { return "Lua"; }
        }
        public override bool GenSyncCode
        {
            get { return LubanDataProxy.LubanEditorData.LuaBinSyncGen; }
            set { LubanDataProxy.LubanEditorData.LuaBinSyncGen = value; }
        }
        public override void ResetLable()
        {
            CodeGenPath = LableConsts.DEFAULT_CODE_GEN_PATH;
            DataGenPath = LableConsts.DEFAULT_DATA_GEN_PATH;
            CodeGenTypeIndex = 1;
            DataGenTypeIndex = 1;
        }
        static class LableConsts
        {
            public const string BAT_NAME = @"gen_code_lua_bin.bat";
            public const string DEFAULT_CODE_GEN_PATH = @"Assets\Gens\LuaBin\Code";
            public const string DEFAULT_DATA_GEN_PATH = @"Assets\Gens\LuaBin\Data";
            public static string[] CodeGenArray { get { return codeGenArray; } }
            public static string[] DataGenArray { get { return dataGenArray; } }
            public static string[] CodeGenSummaryArray { get { return codeGenSummaryArray; } }
            public static string[] DataGenSummaryArray { get { return dataGenSummaryArray; } }

            readonly static string[] codeGenArray = new string[]
            {
                "NONE",
                "code_lua_bin"
            };
            static string[] dataGenArray = new string[]
            {
                "NONE",
                "data_lua"
            };
            readonly static string[] codeGenSummaryArray = new string[]
            {
                "不生成Lua代码",
                "生成lua语言读取bin格式的代码"
            };
            static string[] dataGenSummaryArray = new string[]
            {
                "不生成Lua格式数据",
                "导出lua格式数据"
            };
        }
    }
}