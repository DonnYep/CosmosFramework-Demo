﻿namespace Krypton.Editor.Luban
{
    public class LubanCSBinLable : LubanLableBase
    {
        public override string CodeGenPath
        {
            get { return LubanDataProxy.LubanEditorData.CSBinCodeGenPath; }
            set { LubanDataProxy.LubanEditorData.CSBinCodeGenPath = value; }
        }
        public override string DataGenPath
        {
            get { return LubanDataProxy.LubanEditorData.CSBinDataGenPath; }
            set { LubanDataProxy.LubanEditorData.CSBinDataGenPath = value; }
        }
        public override int DataGenTypeIndex
        {
            get { return LubanDataProxy.LubanEditorData.CSBinDataGenTypeIndex; }
            set { LubanDataProxy.LubanEditorData.CSBinDataGenTypeIndex = value; }
        }
        public override int CodeGenTypeIndex
        {
            get { return LubanDataProxy.LubanEditorData.CSBinCodeGenTypeIndex; }
            set { LubanDataProxy.LubanEditorData.CSBinCodeGenTypeIndex = value; }
        }
        public override string BatchFileAbsPath
        {
            get { return LubanDataProxy.LubanEditorData.CSBinBatchFileAbsPath; }
            set { LubanDataProxy.LubanEditorData.CSBinBatchFileAbsPath = value; }
        }
        public override string[] CodeGenArray
        {
            get { return LableConsts.CodeGenArray; }
        }
        public override string[] DataGenArray
        {
            get { return LableConsts.DataGenArray; }
        }
        public override string[] DataGenSummaryArray
        {
            get { return LableConsts.DataGenSummaryArray; }
        }
        public override string[] CodeGenSummaryArray
        {
            get { return LableConsts.CodeGenSummaryArray; }
        }
        public override string BatName
        {
            get { return LableConsts.BAT_NAME; }
        }
        public override string DefaultCodeGenPath
        {
            get { return LableConsts.DEFAULT_CODE_GEN_PATH; }
        }
        public override string DefaultDataGenPath
        {
            get { return LableConsts.DEFAULT_DATA_GEN_PATH; }
        }
        public override string LableInfo
        {
            get { return "C# Binary 生成面板"; }
        }
        public override string LableDataType
        {
            get { return "Bin"; }
        }
        public override string LableCodeType
        {
            get { return "C#"; }
        }

        public override bool GenSyncCode
        {
            get { return LubanDataProxy.LubanEditorData.CSBinSyncGen; }
            set { LubanDataProxy.LubanEditorData.CSBinSyncGen = value; }
        }

        static class LableConsts
        {
            public static string BAT_NAME = @"gen_code_cs_bin.bat";
            public const string DEFAULT_CODE_GEN_PATH = @"Assets\Gens\CSBin\Code";
            public const string DEFAULT_DATA_GEN_PATH = @"Assets\Gens\CSBin\Data";
            public static string[] CodeGenArray { get { return codeGenArray; } }
            public static string[] DataGenArray { get { return dataGenArray; } }
            public static string[] CodeGenSummaryArray { get { return codeGenSummaryArray; } }
            public static string[] DataGenSummaryArray { get { return dataGenSummaryArray; } }

            readonly static string[] codeGenArray = new string[]
            {
                "NONE",
                "code_cs_unity_bin",
                "code_cs_bin"
            };
            static string[] dataGenArray = new string[]
            {
                "NONE",
                "data_bin"
            };
            readonly static string[] codeGenSummaryArray = new string[]
            {
                 "不生成C#代码",
                "生成适合unity的读取bin格式数据的代码",
                "生成dotnet平台的读取bin格式数据的代码"
            };
            static string[] dataGenSummaryArray = new string[]
            {
                "不生成bin格式数据",
                "导出bin格式数据"
            };
        }
    }
}
