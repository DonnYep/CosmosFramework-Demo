﻿using System.IO;
using UnityEditor;
using UnityEngine;
namespace Krypton.Editor.Luban
{
    public abstract class LubanLableBase
    {
        public abstract string CodeGenPath { get; set; }
        public abstract string DataGenPath { get; set; }
        public abstract int DataGenTypeIndex { get; set; }
        public abstract int CodeGenTypeIndex { get; set; }
        public abstract string BatchFileAbsPath { get; set; }

        public abstract bool GenSyncCode { get; set; }
        public abstract string[] CodeGenArray { get; }
        public abstract string[] DataGenArray { get; }
        public abstract string[] DataGenSummaryArray { get; }
        public abstract string[] CodeGenSummaryArray { get; }

        public abstract string BatName { get; }
        public abstract string DefaultCodeGenPath { get; }
        public abstract string DefaultDataGenPath { get; }
        public abstract string LableInfo { get; }
        public abstract string LableDataType { get; }
        public abstract string LableCodeType { get; }
        public virtual void OnGUI()
        {
            EditorGUILayout.BeginVertical();
            DrawTitle();
            DrawGenTemplate();
            DrawCodeGenLable();
            GUILayout.Space(16);
            DrawDataGenLable();
            DrawGenLable();
            GUILayout.Space(8);
            DrawBatchFileLable();
            EditorGUILayout.EndVertical();
        }
        public virtual void ResetLable()
        {
            CodeGenPath = DefaultCodeGenPath;
            DataGenPath = DefaultDataGenPath;
            CodeGenTypeIndex = 1;
            DataGenTypeIndex = 1;
        }
        protected virtual void DrawGenTemplate()
        {
            GenSyncCode = EditorGUILayout.ToggleLeft("生成脚本是否采用同步加载", GenSyncCode);
        }
        protected virtual void DrawTitle()
        {
            var style = new GUIStyle();
            style.fontSize = 18;
            EditorGUILayout.LabelField(LableInfo, style);
            GUILayout.Space(16);
        }
        protected virtual void DrawBatchFileLable()
        {
            BatchFileAbsPath = Path.Combine(LubanUtility.LubanWorkspacePath(), BatName);
            EditorGUILayout.LabelField("批处理文件地址", BatchFileAbsPath);
            GUILayout.Space(8);
            EditorGUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            if (GUILayout.Button("打开批处理地址", GUILayout.MaxWidth(128)))
            {
                EditorUtility.RevealInFinder(LubanUtility.LubanWorkspacePath());
            }
            if (GUILayout.Button($"重置生成面板", GUILayout.MaxWidth(128)))
            {
                ResetLable();
            }
            EditorGUILayout.EndHorizontal();
            GUILayout.Space(8);
        }
        protected virtual void DrawCodeGenLable()
        {
            EditorGUILayout.BeginVertical("box");
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("代码生成类型");
            CodeGenTypeIndex = EditorGUILayout.Popup(CodeGenTypeIndex, CodeGenArray);
            EditorGUILayout.EndHorizontal();
            GUILayout.Space(8);
            if (CodeGenTypeIndex == 0)
            {
                EditorGUILayout.HelpBox(CodeGenSummaryArray[CodeGenTypeIndex], MessageType.Warning);
            }
            else
            {
                EditorGUILayout.HelpBox(CodeGenSummaryArray[CodeGenTypeIndex], MessageType.Info);
            }
            GUILayout.Space(16);

            var pathNull = string.IsNullOrEmpty(CodeGenPath);
            EditorGUILayout.LabelField($"{LableCodeType}生成路径", pathNull == false ? CodeGenPath : "<NULL>");
            GUILayout.Space(8);
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button($"选择{LableCodeType}生成路径", GUILayout.MaxWidth(128)))
            {
                var srcPath = EditorUtility.OpenFolderPanel("代码生成路径", Application.dataPath, "Assets");
                if (string.IsNullOrEmpty(srcPath))
                    return;
                var isSubPath = Utility.IO.IsSubDirectory(Application.dataPath, srcPath);
                if (isSubPath)
                {
                    CodeGenPath = srcPath.Remove(0, Application.dataPath.Length - 6).Replace("/", "\\");
                }
                else
                {
                    var isConfirm = EditorUtility.DisplayDialog("地址选择错误", $"路径 {srcPath} 不是 Assets目录下的地址，脚本生成路径将会自动被重置！", "确认");
                    if (isConfirm)
                    {
                        CodeGenPath = DefaultCodeGenPath;
                    }
                }
            }
            if (GUILayout.Button($"重置{LableCodeType}生成路径", GUILayout.MaxWidth(128)))
            {
                CodeGenPath = DefaultCodeGenPath;
            }
            if (GUILayout.Button($"打开{LableCodeType}生成路径", GUILayout.MaxWidth(128)))
            {
                if (AssetDatabase.IsValidFolder(CodeGenPath))
                {
                    EditorUtility.RevealInFinder(Path.Combine(Path.GetFullPath("."), CodeGenPath));
                }
                else
                {
                    EditorUtility.RevealInFinder(Application.dataPath);
                }
            }
            GUILayout.FlexibleSpace();
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            if (GUILayout.Button($"重置{LableCodeType}生成配置", GUILayout.MaxWidth(128)))
            {
                CodeGenPath = DefaultCodeGenPath;
                CodeGenTypeIndex = 1;
            }
            EditorGUILayout.EndHorizontal();

            GUILayout.Space(8);

            EditorGUILayout.EndVertical();
        }
        protected virtual void DrawDataGenLable()
        {
            EditorGUILayout.BeginVertical("box");
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("数据生成类型");
            DataGenTypeIndex = EditorGUILayout.Popup(DataGenTypeIndex, DataGenArray);
            EditorGUILayout.EndHorizontal();
            GUILayout.Space(8);

            if (DataGenTypeIndex == 0)
            {
                EditorGUILayout.HelpBox(DataGenSummaryArray[DataGenTypeIndex], MessageType.Warning);
            }
            else
            {
                EditorGUILayout.HelpBox(DataGenSummaryArray[DataGenTypeIndex], MessageType.Info);
            }

            GUILayout.Space(16);

            var pathNull = string.IsNullOrEmpty(DataGenPath);
            EditorGUILayout.LabelField($"{LableDataType}生成路径", pathNull == false ? DataGenPath : "<NULL>");
            GUILayout.Space(8);

            EditorGUILayout.BeginHorizontal();

            if (GUILayout.Button($"选择{LableDataType}生成路径", GUILayout.MaxWidth(128)))
            {
                var srcPath = EditorUtility.OpenFolderPanel("数据生成路径", Application.dataPath, "Assets");
                if (string.IsNullOrEmpty(srcPath))
                    return;
                var isSubPath = Utility.IO.IsSubDirectory(Application.dataPath, srcPath);
                if (isSubPath)
                {
                    DataGenPath = srcPath.Remove(0, Application.dataPath.Length - 6).Replace("/", "\\");
                }
                else
                {
                    var isConfirm = EditorUtility.DisplayDialog("地址选择错误", $"路径 {srcPath} 不是 Assets目录下的地址，脚本生成路径将会自动被重置！", "确认");
                    if (isConfirm)
                    {
                        DataGenPath = DefaultDataGenPath;
                    }
                }
            }
            if (GUILayout.Button($"重置{LableDataType}生成路径", GUILayout.MaxWidth(128)))
            {
                DataGenPath = DefaultDataGenPath;
            }
            if (GUILayout.Button($"打开{LableDataType}生成路径", GUILayout.MaxWidth(128)))
            {
                if (AssetDatabase.IsValidFolder(DataGenPath))
                {
                    EditorUtility.RevealInFinder(Path.Combine(Path.GetFullPath("."), DataGenPath));
                }
                else
                {
                    EditorUtility.RevealInFinder(Application.dataPath);
                }
            }
            GUILayout.FlexibleSpace();

            EditorGUILayout.EndHorizontal();

            EditorGUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            if (GUILayout.Button($"重置{LableDataType}生成配置", GUILayout.MaxWidth(128)))
            {
                DataGenPath = DefaultDataGenPath;
                DataGenTypeIndex = 1;
            }
            EditorGUILayout.EndHorizontal();

            GUILayout.Space(8);

            EditorGUILayout.EndVertical();
        }
        protected virtual void DrawGenLable()
        {
            GUILayout.Space(8);
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("生成批处理"))
            {
                if ((CodeGenTypeIndex + DataGenTypeIndex) == 0)
                {
                    EditorUtility.DisplayDialog("生成错误", "代码与数据生成类型不可以同时为 NONE ！", "确认");
                    return;
                }
                GenerateBatchFile();
            }
            if (GUILayout.Button("运行批处理"))
            {
                if (!File.Exists(BatchFileAbsPath))
                {
                    EditorUtility.DisplayDialog("文件不存在", "批处理文件不存在，请点击\"生成批处理按钮\"", "确认");
                    return;
                }
                if ((CodeGenTypeIndex + DataGenTypeIndex) == 0)
                {
                    EditorUtility.DisplayDialog("运行错误", "代码与数据生成类型不可以同时为 NONE ！", "确认");
                    return;
                }
                var run = EditorUtility.DisplayDialog("生成数据", "是否确认生成数据", "确认", "取消");
                if (run)
                {
                    Utility.Program.StartProcess(BatchFileAbsPath);
                }
            }
            EditorGUILayout.EndHorizontal();
        }
        protected virtual void GenerateBatchFile()
        {
            bool isNone = false;
            string batContext = string.Empty;
            if (!GenSyncCode)
            {
                batContext = LubanUtility.AsyncTplBatContext;
            }
            else
            {
                batContext = LubanUtility.BatContext;
            }
            batContext = batContext.Replace(LubanUtility.DATA_GEN_PATH, DataGenPath);
            batContext = batContext.Replace(LubanUtility.CODE_GEN_PATH, CodeGenPath);
            var dataTypeIdx = DataGenTypeIndex;
            var dataGenType = DataGenArray[dataTypeIdx];
            if (dataGenType == LubanUtility.NONE)
            {
                batContext = batContext.Replace(LubanUtility.DATA_GEN_TYPE, "");
                isNone = true;
            }
            else
            {
                batContext = batContext.Replace(LubanUtility.DATA_GEN_TYPE, dataGenType);
            }
            var codeTypeIdx = CodeGenTypeIndex;
            var codeGenType = CodeGenArray[codeTypeIdx];
            if (codeGenType == LubanUtility.NONE)
            {
                batContext = batContext.Replace(LubanUtility.CODE_GEN_TYPE, "");
                isNone = true;
            }
            else
            {
                batContext = batContext.Replace(LubanUtility.CODE_GEN_TYPE, codeGenType);
            }
            if (isNone)
                batContext = batContext.Replace(LubanUtility.DOT, "");
            else
                batContext = batContext.Replace(LubanUtility.DOT, LubanUtility.DOT_VALUE);
            Utility.IO.OverwriteTextFile(BatchFileAbsPath, batContext);
            EditorUtility.DisplayDialog("生成成功", "批处理文件生成成功！", "确认");
        }
    }
}
