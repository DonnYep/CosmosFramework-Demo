﻿using System.IO;
namespace Krypton.Editor.Luban
{
    public partial class LubanUtility
    {
        static string lubanWorkspacePath;
        public static string LubanWorkspacePath()
        {
            if (string.IsNullOrEmpty(lubanWorkspacePath))
                lubanWorkspacePath = Path.Combine(Path.GetFullPath("."), LUBAN_BAT_PATH);
            return lubanWorkspacePath;
        }
        public const string LUBAN_BAT_PATH = @"Luban";

        public const string GEN_CODE_DATA_BAT = @"gen_code_data.bat";

        #region 默认生成地址
        /// <summary>
        /// 默认数据生成地址
        /// </summary>
        public const string DEFAULT_DATA_GEN_PATH = @"Assets\Gens\Data";
        /// <summary>
        /// 默认代码生成地址
        /// </summary>
        public const string DEFAULT_CODE_GEN_PATH = @"Assets\Gens\Code";
        #endregion

        #region 代码生成相关
        /// <summary>
        /// 代码生成类型
        /// </summary>
        public const string CODE_GEN_TYPE = @"#CODE_GEN_TYPE#";
        /// <summary>
        /// 代码生成地址
        /// </summary>
        public const string CODE_GEN_PATH = @"#CODE_GEN_PATH#";
        #endregion

        #region 数据生成相关
        /// <summary>
        /// 数据生成类型
        /// </summary>
        public const string DATA_GEN_TYPE = @"#DATA_GEN_TYPE#";
        /// <summary>
        /// 数据生成地址
        /// </summary>
        public const string DATA_GEN_PATH = @"#DATA_GEN_PATH#";
        #endregion

        public const string DOT = @"#DOT#";
        public const string DOT_VALUE = @",";

        public const string NONE = @"NONE";

        public const string BatContext =
@"set UNITY_WORKSPACE=%cd%
set WORKSPACE=%cd%\Luban
set GEN_CLIENT=%WORKSPACE%\Tools\Luban.ClientServer\Luban.ClientServer.exe
set CONF_ROOT=%WORKSPACE%\DesignerConfigs
%GEN_CLIENT% -j cfg --^
 -d %CONF_ROOT%\Defines\__root__.xml ^
 --input_data_dir %CONF_ROOT%\Datas ^
 --output_code_dir #CODE_GEN_PATH# ^
 --output_data_dir  #DATA_GEN_PATH# ^
  --gen_types #CODE_GEN_TYPE##DOT##DATA_GEN_TYPE# ^
 -s all 
pause";

        public const string TEMPLATE_PATH = @"#TEMPLATE_PATH#";

        /// <summary>
        /// 自定义模板批处理内容；
        /// </summary>
        public const string AsyncTplBatContext =
@"set UNITY_WORKSPACE=%cd%
set WORKSPACE=%cd%\Luban
set GEN_CLIENT=%WORKSPACE%\Tools\Luban.ClientServer\Luban.ClientServer.exe
set CONF_ROOT=%WORKSPACE%\DesignerConfigs
set TPL_PATH=%WORKSPACE%\CustomTemplate
%GEN_CLIENT% --template_search_path %TPL_PATH% -j cfg --^
 -d %CONF_ROOT%\Defines\__root__.xml ^
 --input_data_dir %CONF_ROOT%\Datas ^
 --output_code_dir #CODE_GEN_PATH# ^
 --output_data_dir  #DATA_GEN_PATH# ^
  --gen_types #CODE_GEN_TYPE##DOT##DATA_GEN_TYPE# ^
 -s all 
pause";
    }
}
