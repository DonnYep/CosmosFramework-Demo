﻿namespace Bright.Serialization
{
    public interface ITypeId
    {
        int GetTypeId();
    }
}
