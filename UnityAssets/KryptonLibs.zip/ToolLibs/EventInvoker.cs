using System.Collections;
using UnityEngine;
using UnityEngine.Events;
namespace Krypton
{
    public class EventInvoker : MonoBehaviour
    {
        [SerializeField] UnityEvent events;
        [SerializeField] UnityEvent delayEvents;
        Coroutine delayRoutine;
        public void InvokeEvent()
        {
            events?.Invoke();
        }
        public void DelayInvokeEvent(float delay)
        {
            if (delayRoutine != null)
                StopCoroutine(delayRoutine);
            delayRoutine = StartCoroutine(DelayInvoke(delay));
        }
        IEnumerator DelayInvoke(float delay)
        {
            yield return new WaitForSeconds(delay);
            delayEvents?.Invoke();
        }
    }
}