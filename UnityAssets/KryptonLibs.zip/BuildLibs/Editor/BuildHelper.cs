using UnityEditor;
using System.IO;
using System.Collections.Generic;
using System;
public class BuildHelper
{
    [MenuItem("Window/Krypton/ExportAndroidProject", false, 100)]
    public static void BuildAndExportAndroidProject()
    {
        Quark.Editor.QuarkBuildPipeline.BuildAssetBundle(BuildTarget.Android);
        var projectPath = Path.GetFullPath(".");
        var buildPath = Path.Combine(projectPath, "Build", "AndroidProject");
        if (Directory.Exists(buildPath))
            Directory.Delete(buildPath, true);
        Directory.CreateDirectory(buildPath);
        BuildPlayerOptions buildPlayerOptions = new BuildPlayerOptions();
        buildPlayerOptions.locationPathName = buildPath;
        buildPlayerOptions.target = BuildTarget.Android;
        //var quarkScenes = Quark.Editor.QuarkBuildPipeline.GetBuildScenePath();
        //var editorScenes = FindEnabledEditorScenes();
        //var quarkSceneLen = quarkScenes.Length;
        //var editorSceneLen = editorScenes.Length;
        //var allScenes = new string[quarkSceneLen + editorSceneLen];
        //Array.Copy(editorScenes, 0, allScenes, 0, editorSceneLen);
        //Array.Copy(quarkScenes, 0, allScenes, editorSceneLen, quarkSceneLen);
        buildPlayerOptions.scenes = FindEnabledEditorScenes();
        EditorUserBuildSettings.exportAsGoogleAndroidProject = true;
#if UNITY_2021_1_OR_NEWER
        EditorUserBuildSettings.androidCreateSymbols = AndroidCreateSymbols.Public;
#else
        EditorUserBuildSettings.androidCreateSymbolsZip = true;
#endif
        BuildPipeline.BuildPlayer(buildPlayerOptions);
    }
    static string[] FindEnabledEditorScenes()
    {
        List<string> names = new List<string>();
        foreach (EditorBuildSettingsScene scene in EditorBuildSettings.scenes)
        {
            if (scene == null) continue;
            if (scene.enabled) names.Add(scene.path);
        }
        return names.ToArray();
    }
}