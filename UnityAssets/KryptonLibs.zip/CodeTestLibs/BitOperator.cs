using System.Collections.Generic;
using UnityEngine;

public class BitOperator : MonoBehaviour
{
    [SerializeField] int value = 21845;
    [SerializeField]List<string> hexChars = new List<string>()
    {
        "0", "1", "2", "3", "4", "5","6","7","8","9" ,"A","B","C","D","E","F"
    };
}
