using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

[CustomEditor(typeof(BitOperator))]
public class BitOperatorEditor : UnityEditor.Editor
{
    SerializedObject targetObject;
    BitOperator bitOperator;
    SerializedProperty sp_hexs;
    SerializedProperty sp_hexValue;
    int hexValue;
    string[] hexsArr;
    public override void OnInspectorGUI()
    {
        targetObject.Update();
        hexValue = EditorGUILayout.MaskField(sp_hexValue.intValue, hexsArr);
        if (hexValue != sp_hexValue.intValue)
        {
            sp_hexValue.intValue = hexValue;
        }
        EditorGUILayout.IntField("Value",hexValue);
        targetObject.ApplyModifiedProperties();
    }
    private void OnEnable()
    {
        bitOperator = target as BitOperator;
        targetObject = new SerializedObject(bitOperator);
        sp_hexs = targetObject.FindProperty("hexChars");
        sp_hexValue = targetObject.FindProperty("value");
        hexValue = sp_hexValue.intValue;
        var hexs = new List<string>();
        var length = sp_hexs.arraySize;
        for (int i = 0; i < length; i++)
        {
            hexs.Add(sp_hexs.GetArrayElementAtIndex(i).stringValue);
        }
        hexsArr = hexs.ToArray();
    }
}
