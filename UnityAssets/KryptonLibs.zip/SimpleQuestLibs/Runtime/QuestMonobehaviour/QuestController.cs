﻿using UnityEngine;
namespace Krypton.SimpleQuest
{
    public class QuestController : MonoBehaviour
    {
        /// <summary>
        /// 存储任务进度
        /// </summary>
        public void SaveArchiveToLocal()
        {
            QuestManager.Instance.SaveArchiveToLocal();
        }
        public void FinishQuest(string questId)
        {
            QuestManager.Instance.FinishQuest(questId);
        }
        public void ActiveQuest(string questId)
        {
            QuestManager.Instance.ActiveQuest(questId);
        }
        public string[] GetActiveQuests()
        {
            return QuestManager.Instance.ActiveQuests;
        }
        public bool IsQuestActive(string questId)
        {
            return QuestManager.Instance.IsQuestActive(questId);
        }
    }
}
