﻿using UnityEngine;
using UnityEngine.Events;

namespace Krypton.SimpleQuest
{
    public class QuestTriggerEvents : MonoBehaviour
    {
        [SerializeField] protected UnityEvent onAnyQuestActive;
        [SerializeField] protected UnityEvent onAnyQuestDone;
        public UnityEvent OnAnyQuestActive
        {
            get { return onAnyQuestActive; }
            set { onAnyQuestActive = value; }
        }
        public UnityEvent OnAnyQuestDone
        {
            get { return OnAnyQuestDone; }
            set { OnAnyQuestDone = value; }
        }
        void Awake()
        {
            QuestManager.Instance.OnQuestActive += OnQuestStart;
            QuestManager.Instance.OnQuestFinish += OnQuestDone;
        }
        void OnDestroy()
        {
            QuestManager.Instance.OnQuestActive -= OnQuestStart;
            QuestManager.Instance.OnQuestFinish -= OnQuestDone;
        }
        void OnQuestDone(QuestNode questNode)
        {
            onAnyQuestActive?.Invoke();
        }
        void OnQuestStart(QuestNode questNode)
        {
            onAnyQuestDone?.Invoke();
        }
    }
}
