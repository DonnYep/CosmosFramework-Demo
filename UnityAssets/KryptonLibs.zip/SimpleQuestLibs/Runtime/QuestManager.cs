﻿using System;

namespace Krypton.SimpleQuest
{
    //================================================
    /*
     * 1、任务系统在Iris项目中的需求是，当一个任务完成，则这个这个任务状态
     * 变更为Done。Done状态的任务会进入任务完成列表或者成就系统中，同时
     * currentQuestNode的状态变更为NONE。只有当触发或者接取任务时，当前
     * 任务的node才会存在数据。
     * 
     * 2、任务虽然从策划案上设计是连续的，但是在数据存储的角度触发，单个
     * 任务节点是离散的。由于代码设计上任务点并不连续，因此需要从使用的
     * 角度尽量避免直接进入下一个节点的问题。
     * 
     * 3、任务的几种状态含，待领取，领取&激活，成功，失败，放弃等。
     * 
     * 4、Iris项目的逻辑为，激活状态只存在一个任务。当任务激活，则持有被
     * 激活的任务，并触发激活事件。当任务完成，激活的任务状态更改为完成
     * 状态，触发完成事件，事件触发完毕后，清空被持有的任务。
     * 
     * Max、Merge Conflict
     * 
     */
    //================================================
    public class QuestManager : Singleton<QuestManager>
    {
        Action<QuestNode> onQuestActive;
        Action<QuestNode> onQuestFinish;
        public event Action<QuestNode> OnQuestActive
        {
            add { onQuestActive += value; }
            remove { onQuestActive -= value; }
        }
        public event Action<QuestNode> OnQuestFinish
        {
            add { onQuestFinish += value; }
            remove { onQuestFinish -= value; }
        }
        public string[] ActiveQuests
        {
            get { return QuestProxy.ActiveQuestIds.ToArray(); }
        }
        /// <summary>
        /// 初始化，这里会加载任务配表、存档、以及组装任务链；
        /// </summary>
        public void Init(IQuestDataHelper questDataHelper)
        {
            QuestUtility.SetQuestDataHelper(questDataHelper);
            QuestProxy.InitData();
        }
        /// <summary>
        /// 任务提示是否解锁；
        /// </summary>
        /// <param name="questId">任务Id</param>
        /// <returns>是否解锁</returns>
        public bool IsQuestTipUnlocked(string questId)
        {
            return QuestProxy.IsQuestTipUnlocked(questId);
        }
        public bool UnlockQuestTip(string questId)
        {
            return QuestProxy.UnlockQuestTip(questId);
        }
        public bool IsQuestActive(string questId)
        {
            return QuestProxy.IsQuestActive(questId);
        }
        /// <summary>
        /// 激活任务;
        /// </summary>
        /// <param name="questId">任务Id</param>
        public void ActiveQuest(string questId)
        {
            if (QuestProxy.AcquireQuestNode(questId, out var node))
            {
                ActiveQuest(node);
            }
        }
        /// <summary>
        /// 完成任务；
        /// </summary>
        /// <param name="questId">任务Id</param>
        public void FinishQuest(string questId)
        {
            if (QuestProxy.AcquireQuestNode(questId, out var node))
            {
                FinishQuest(node);
            }
        }
        public QuestNodeInfo[] GetActiveQuests()
        {
            var length = ActiveQuests.Length;
            QuestNodeInfo[] infos = new QuestNodeInfo[length];
            for (int i = 0; i < length; i++)
            {
                QuestProxy.PeekQuestData(ActiveQuests[i], out var questData);
                var isUnlocked = QuestProxy.IsQuestTipUnlocked(questData.QuestId);
                infos[i] = new QuestNodeInfo()
                {
                    QuestTipUnlocked = isUnlocked,
                    QuestContext = questData.QuestText,
                    QuestHeader = questData.QuestHeader,
                    QuestId = questData.QuestId,
                    QuestState = QuestState.Active,
                    QuestTipContext = questData.QuestTipContext
                };
            }
            return infos;
        }
        public void ReadArchiveFromLocal()
        {
            QuestProxy.InitData();
        }
        /// <summary>
        /// 存储存档到本地；
        /// </summary>
        public void SaveArchiveToLocal()
        {
            QuestProxy.SaveArchiveToLocal();
        }
        /// <summary>
        /// 任务是否已经完成过；
        /// </summary>
        /// <param name="questId">任务Id</param>
        /// <returns>是否完成</returns>
        public bool IsQuestFinished(string questId)
        {
            return QuestProxy.IsQuestFinished(questId);
        }
        /// <summary>
        /// 激活任务后，验证任务是否完成过。
        /// 若完成过，则不会进行触发。
        /// 若未完成，则当前任务更改为被触发的任务节点。
        /// </summary>
        void ActiveQuest(QuestNode node)
        {
            if (QuestProxy.IsQuestFinished(node.QuestId))//判断是否是完成的任务
                return;
            if (QuestProxy.AddActiveQuest(node.QuestId))
            {
                //激活成功；
                node.QuestState = QuestState.Active;
                onQuestActive?.Invoke(node);
            }
        }
        void FinishQuest(QuestNode node)
        {
            if (QuestProxy.IsQuestFinished(node.QuestId))//判断是否是完成的任务
                return;
            //判断任务状态是否处于激活
            if (QuestProxy.IsQuestActive(node.QuestId))
            {
                QuestProxy.RemoveActiveQuest(node.QuestId);
                node.QuestState = QuestState.Done;
                onQuestFinish?.Invoke(node);
                QuestProxy.AddFinishQuestId(node.QuestId);
            }
        }
    }
}
