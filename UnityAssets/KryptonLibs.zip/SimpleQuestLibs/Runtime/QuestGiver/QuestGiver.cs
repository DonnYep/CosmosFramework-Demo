﻿using UnityEngine;
namespace Krypton.SimpleQuest
{
    /// <summary>
    /// 任务给予者；
    /// </summary>
    [AddComponentMenu("")]
    public class QuestGiver : MonoBehaviour
    {
        //Iris版本暂不实现功能

    }
}
