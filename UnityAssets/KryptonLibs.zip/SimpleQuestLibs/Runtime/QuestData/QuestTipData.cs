﻿using System;

namespace Krypton.SimpleQuest
{
    [Serializable]
    public class QuestTipData
    {
        /// <summary>
        /// 任务的唯一Id
        /// </summary>
        public string QuestId;
        /// <summary>
        /// 任务提示内容；
        /// </summary>
        public string QuestTipContext;

    }
}
