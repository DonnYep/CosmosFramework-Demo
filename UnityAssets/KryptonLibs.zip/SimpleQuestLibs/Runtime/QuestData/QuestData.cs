﻿using System;
namespace Krypton.SimpleQuest
{
    [Serializable]
    public class QuestData
    {
        /// <summary>
        /// 任务的唯一Id
        /// </summary>
        public string QuestId;
        /// <summary>
        /// 任务标题；
        /// </summary>
        public string QuestHeader;
        /// <summary>
        /// 任务选项；
        /// </summary>
        public string QuestText;
        /// <summary>
        /// 任务提示内容；
        /// </summary>
        public string QuestTipContext;
        /// <summary>
        /// 任务奖励Id；
        /// 注意，这个奖励Id应该是全局唯一我物品；
        /// </summary>
        public int[] QuestRewards;
        /// <summary>
        /// 下一个任务Id，这点主要用于棱形分支；
        /// </summary>
        public string[] NextQuestIds;
    }
}
