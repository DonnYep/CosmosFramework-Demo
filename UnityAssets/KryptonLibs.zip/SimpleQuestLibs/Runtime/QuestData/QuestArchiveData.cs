﻿using System;

namespace Krypton.SimpleQuest
{
    /// <summary>
    /// 任务存档数据，用于持久化的数据结构；
    /// </summary>
    [Serializable]
    public class QuestArchiveData
    {
        /// <summary>
        /// 激活的任务Id；
        /// </summary>
        public string[] ActiveQuestIds;
        /// <summary>
        /// 完成的任务Id；
        /// </summary>
        public string[] FinishedQuestIds;
        /// <summary>
        /// 解锁的任务提示Id
        /// </summary>
        public string[] UnlockedTipQuestIds;
    }
}
