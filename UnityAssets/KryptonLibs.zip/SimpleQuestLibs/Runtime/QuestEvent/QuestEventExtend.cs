﻿using System;

namespace Krypton.SimpleQuest.Event
{
    public static class QuestEventExtend
    {
        public static void AddQuestListener(this IQuestNotification @this, Action<QuestNode> action)
        {

        }
        public static void RemoveQuestListener(this IQuestNotification @this, Action<QuestNode> action)
        {

        }
    }
}
