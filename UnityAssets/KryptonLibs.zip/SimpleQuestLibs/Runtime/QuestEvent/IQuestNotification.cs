﻿namespace Krypton.SimpleQuest.Event
{
    /// <summary>
    /// 任务消息接口，实现此接口后可以监听任务事件；
    /// </summary>
    public interface IQuestNotification
    {
    }
}
