﻿using System;
using System.Collections.Generic;

namespace Krypton.SimpleQuest.Event
{
    public class QuestEventCenter
    {
        Dictionary<object, List<Action<QuestData>>> questListenerDict
            = new Dictionary<object, List<Action<QuestData>>>();
        public static void DispatchEvent(QuestData questData)
        {

        }
    }
}
