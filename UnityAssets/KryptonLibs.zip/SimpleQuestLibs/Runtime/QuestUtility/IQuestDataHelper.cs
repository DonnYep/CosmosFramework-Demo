﻿using System.Collections.Generic;
namespace Krypton.SimpleQuest
{
    public interface IQuestDataHelper
    {
        void SaveArchiveToLocal(QuestArchiveData archiveData);
        QuestArchiveData LoadArchiveFromLocal();
        /// <summary>
        /// 获取任务数据配表；
        /// </summary>
        List<QuestData> LoadQuestDatas();
    }
}
