﻿using System.Collections.Generic;

namespace Krypton.SimpleQuest
{
    public class QuestUtility
    {
        static IQuestDataHelper questDataHelper;
        /// <summary>
        /// 设置任务数据帮助体；
        /// </summary>
        public static void SetQuestDataHelper(IQuestDataHelper helper)
        {
            questDataHelper = helper;
        }
        /// <summary>
        /// 保存任务存档到本地；
        /// </summary>
        public static void SaveArchiveToLocal(QuestArchiveData questArchiveData)
        {
            questDataHelper.SaveArchiveToLocal(questArchiveData);
        }
        /// <summary>
        /// 从本地加载任务存档；
        /// </summary>
        public static QuestArchiveData LoadArchiveFromLocal()
        {
            return questDataHelper.LoadArchiveFromLocal();
        }
        /// <summary>
        /// 获取任务配表数据；
        /// </summary>
        public static List<QuestData> LoadQuestDatas()
        {
            return questDataHelper.LoadQuestDatas();
        }
    }
}
