﻿namespace Krypton.SimpleQuest
{
    public class QuestOption
    {
        /// <summary>
        /// 选项Id
        /// </summary>
        public string QuestOptionId;
        /// <summary>
        /// 选项标题
        /// </summary>
        public string QuestOptionHeader;
        /// <summary>
        /// 选项内容
        /// </summary>
        public string QuestOptionContext;
    }
}
