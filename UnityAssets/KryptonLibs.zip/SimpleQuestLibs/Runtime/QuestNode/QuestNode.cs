﻿using System;
namespace Krypton.SimpleQuest
{
    /// <summary>
    /// 注意，quest node 在任务模块运行时是组装执行的。
    /// questNode支持引用池
    /// </summary>
    public class QuestNode : IEquatable<QuestNode>, IReference
    {
        string questId;
        QuestState questState;
        QuestData questData;
        /// <summary>
        /// 任务全局Id
        /// </summary>
        public string QuestId
        {
            get { return questId; }
            set { questId = value; }
        }
        /// <summary>
        /// 任务状态；
        /// </summary>
        public QuestState QuestState
        {
            get { return questState; }
            set { questState = value; }
        }
        public QuestData QuestData
        {
            get { return questData; }
            set { questData = value; }
        }
        public bool Equals(QuestNode other)
        {
            return other.questId == this.questId;
        }
        public override bool Equals(object other)
        {
            return Equals((QuestNode)other);
        }
        public void Release()
        {
            questId = "<NULL>";
            questState = QuestState.Wait;
            questData = default;
        }
    }
}
