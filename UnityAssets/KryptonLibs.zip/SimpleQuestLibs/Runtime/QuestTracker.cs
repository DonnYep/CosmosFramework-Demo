﻿using System.Collections;
using UnityEngine;
using UnityEngine.Events;
namespace Krypton.SimpleQuest
{
    /// <summary>
    /// 任务追踪；
    /// </summary>
    public class QuestTracker : MonoBehaviour
    {
        [SerializeField] UnityEvent onStart;
        [SerializeField] float delayTime = 5f;
        [SerializeField] UnityEvent onDelayStart;
        private void Start()
        {
            onStart?.Invoke();
            StartCoroutine(Delay());
        }
        IEnumerator Delay()
        {
            yield return new WaitForSeconds(delayTime);
            onDelayStart?.Invoke();
        }
    }
}
