﻿using System.Runtime.InteropServices;
namespace Krypton.SimpleQuest
{
    [StructLayout(LayoutKind.Auto)]
    public struct QuestNodeInfo
    {
        /// <summary>
        /// 任务Id
        /// </summary>
        public string QuestId;
        /// <summary>
        /// 任务标题
        /// </summary>
        public string QuestHeader;
        /// <summary>
        /// 任务内容
        /// </summary>
        public string QuestContext;
        /// <summary>
        /// 任务状态
        /// </summary>
        public QuestState QuestState;
        /// <summary>
        /// 是否解锁了；
        /// </summary>
        public bool QuestTipUnlocked;
        /// <summary>
        /// 提示内容
        /// </summary>
        public string QuestTipContext;
    }
}
