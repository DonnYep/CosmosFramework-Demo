﻿namespace Krypton.SimpleQuest
{
    /// <summary>
    /// 任务奖励；
    /// </summary>
    public class QuestReward
    {
    }
}
