﻿using System.Collections.Generic;

namespace Krypton.SimpleQuest
{
    internal class QuestProxy
    {
        static Dictionary<string, QuestData> questDataDict
            = new Dictionary<string, QuestData>();

        static Dictionary<string, QuestTipData> questTipDataDict
            = new Dictionary<string, QuestTipData>();

        /// <summary>
        /// 解锁的任务提示；
        /// </summary>
        static List<string> unlockedTipsQuestIds = new List<string>();
        /// <summary>
        /// 已经完成的任务Id;
        /// </summary>
        static List<string> finishedQuestIds = new List<string>();
        /// <summary>
        /// 激活的任务
        /// </summary>
        static List<string> activeQuestIds = new List<string>();
        public static List<string> ActiveQuestIds
        {
            get { return activeQuestIds; }
        }
        public static List<string> FinishedQuestIds
        {
            get { return finishedQuestIds; }
        }
        public static List<string> UnlockedTipsQuestIds
        {
            get { return unlockedTipsQuestIds; }
        }
        public static void InitData()
        {
            var datas = QuestUtility.LoadQuestDatas();
            foreach (var data in datas)
            {
                questDataDict.TryAdd(data.QuestId, data);//初始化数据
            }
            var archive = QuestUtility.LoadArchiveFromLocal();
            if (archive.FinishedQuestIds != null)
                finishedQuestIds.AddRange(archive.FinishedQuestIds);
            activeQuestIds?.Clear();
            if (archive.ActiveQuestIds != null)
                activeQuestIds.AddRange(archive.ActiveQuestIds);
            unlockedTipsQuestIds?.Clear();
            if (archive.UnlockedTipQuestIds != null)
                unlockedTipsQuestIds.AddRange(archive.UnlockedTipQuestIds);
        }
        public static bool AddActiveQuest(string questId)
        {
            if (!questDataDict.ContainsKey(questId))
                return false;
            if (!activeQuestIds.Contains(questId))
            {
                activeQuestIds.Add(questId);
                return true;
            }
            return false;
        }
        public static bool RemoveActiveQuest(string questId)
        {
            if (!questDataDict.ContainsKey(questId))
                return false;
            return activeQuestIds.Remove(questId);
        }
        public static bool IsQuestActive(string questId)
        {
            return activeQuestIds.Contains(questId);
        }
        public static bool AcquireQuestNode(string questId, out QuestNode questNode)
        {
            questNode = default;
            var hasQuest = questDataDict.TryGetValue(questId, out var questData);
            if (!hasQuest)
                return false;
            questNode = new QuestNode()
            {
                QuestId = questData.QuestId,
                QuestData = questData,
                QuestState = QuestState.Wait
            };
            if (IsQuestActive(questId))
                questNode.QuestState = QuestState.Active;
            else if (IsQuestFinished(questId))
                questNode.QuestState = QuestState.Done;
            return true;
        }
        public static bool PeekQuestData(string questId, out QuestData questData)
        {
            return questDataDict.TryGetValue(questId, out questData);
        }
        public static void AddQuestTipData(IEnumerable<QuestTipData> questTipDatas)
        {
            foreach (var tipData in questTipDatas)
            {
                questTipDataDict.TryAdd(tipData.QuestId, tipData);
            }
        }
        public static bool IsQuestTipUnlocked(string questId)
        {
            if (!questDataDict.ContainsKey(questId))
                return false;
            return unlockedTipsQuestIds.Contains(questId);
        }
        public static bool UnlockQuestTip(string questId)
        {
            if (!questDataDict.ContainsKey(questId))
                return false;
            if (!unlockedTipsQuestIds.Contains(questId))
            {
                unlockedTipsQuestIds.Add(questId);
                return true;
            }
            return false;
        }
        /// <summary>
        /// 任务是否已经完成过；
        /// </summary>
        /// <param name="questId">任务Id</param>
        /// <returns>是否完成</returns>
        public static bool IsQuestFinished(string questId)
        {
            return finishedQuestIds.Contains(questId);
        }
        public static void SaveArchiveToLocal()
             
        {
            var questArchiveData = new QuestArchiveData()
            {
                ActiveQuestIds = activeQuestIds?.ToArray(),
                FinishedQuestIds = finishedQuestIds.ToArray(),
                UnlockedTipQuestIds = unlockedTipsQuestIds.ToArray()
            };
            QuestUtility.SaveArchiveToLocal(questArchiveData);
        }
        public static bool AddFinishQuestId(string questId)
        {
            if (!finishedQuestIds.Contains(questId))
            {
                finishedQuestIds.Add(questId);
                return true;
            }
            return false;
        }
    }
}
