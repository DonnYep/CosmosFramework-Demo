﻿namespace Krypton.SimpleQuest
{
    /// <summary>
    /// 任务状态；
    /// </summary>
    public enum QuestState
    {
        Wait,
        Active,
        Done,
    }
}
