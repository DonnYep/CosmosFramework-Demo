﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Krypton.SimpleQuest
{
    /// <summary>
    /// 任务提示UI接口
    /// </summary>
    public interface IQuestUI
    {

    }
}
