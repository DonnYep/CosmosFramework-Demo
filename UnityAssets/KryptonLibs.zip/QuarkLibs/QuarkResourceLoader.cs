﻿using System;
using UnityEngine;
using Quark;
namespace Krypton
{
    public class QuarkResourceLoader : IResouceLoader
    {
        public GameObject LoadPrefab(string assetName, bool instantiate)
        {
            return QuarkResources.LoadPrefab(assetName, instantiate);
        }
        public UnityEngine.Object LoadAsset(string assetName, Type type)
        {
            return QuarkResources.LoadAsset(assetName, type);
        }
        public T LoadAsset<T>(string assetName) where T : UnityEngine.Object
        {
            return QuarkResources.LoadAsset<T>(assetName);
        }
        public void LoadAssetAsync<T>(string assetName, Action<T> callback) where T : UnityEngine.Object
        {
            QuarkResources.LoadAssetAsync<T>(assetName, callback);
        }
        public void LoadAssetAsync(string assetName, Action<UnityEngine.Object> callback) 
        {
            QuarkResources.LoadAssetAsync(assetName, callback);
        }
        public UnityEngine.Object[] LoadAllAssets(string assetBundleName)
        {
            return QuarkResources.LoadAllAssets(assetBundleName);
        }
        public void UnloadAsset(string assetName)
        {
            QuarkResources.UnloadAsset(assetName);
        }
        public void UnloadAllAsset(bool unloadAllLoadedObjects = false)
        {
            QuarkResources.UnloadAllAssetBundle(unloadAllLoadedObjects);
        }
        public void UnloadAssetBundle(string assetBundleName)
        {
            QuarkResources.UnloadAssetBundle(assetBundleName);
        }

        public bool GetResourceInfo(string assetName, out ResourceInfo info)
        {
            info = ResourceInfo.NONE;
            var rst = QuarkResources.GetObjectInfo(assetName, out var srcInfo);
            if (rst)
            {
                info = new ResourceInfo(srcInfo.AssetName, srcInfo.AssetPath,
                    srcInfo.AssetBundleName, srcInfo.AssetExtension, srcInfo.AssetType,
                    srcInfo.ReferenceCount);
                return true;
            }
            return false;
        }
        public ResourceInfo[] GetAllResourceInfos()
        {
            var quarkInfos = QuarkResources.GetAllLoadedObjectInfo();
            ResourceInfo[] infos = new ResourceInfo[quarkInfos.Length];
            for (int i = 0; i < infos.Length; i++)
            {
                var qInfo = quarkInfos[i];
                infos[i] = new ResourceInfo(qInfo.AssetName, qInfo.AssetPath, qInfo.AssetBundleName, qInfo.AssetExtension, qInfo.AssetType, qInfo.ReferenceCount);
            }
            return infos;
        }
        public ResourceVersion GetResourceVersion()
        {
            var buildVersion = QuarkResources.GetBuildVersion();
            var resVersion = new ResourceVersion(buildVersion, "Resource build by quark asset");
            return resVersion;
        }
        public void LoadMainAndSubAssetsAsync<T>(string assetName, Action<T[]> callback) where T : UnityEngine.Object
        {
        }

        public void LoadSceneAsync(string sceneName, Func<float> progressProvider, Action<float> progress, Func<bool> condition, Action callback, bool additive = false)
        {
        }

        public void UnloadSceneAsync(string sceneName, Action<float> progress, Action callback)
        {
        }
    }
}
