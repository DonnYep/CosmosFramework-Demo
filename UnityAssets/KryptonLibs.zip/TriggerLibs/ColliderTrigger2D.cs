using System.Collections.Generic;
using UnityEngine;

namespace Krypton
{
    [RequireComponent(typeof(ColliderTriggerEvents))]
    /// <summary>
    /// 触发器；
    /// </summary>
    public class ColliderTrigger2D : MonoBehaviour
    {
        [SerializeField] protected List<string> triggerableTags;
        [SerializeField] protected int tagsBits;
        protected ColliderTriggerEvents colliderTriggerEvents;
        public List<string> TriggerableTags
        {
            get { return triggerableTags; }
        }
        protected virtual void OnTriggerEnter2D(Collider2D collision)
        {
            var collTag = collision.tag;
            if (triggerableTags.Contains(collTag))
            {
                colliderTriggerEvents.OnTriggerEnterEvent();
            }
        }
        protected virtual void OnTriggerExit2D(Collider2D collision)
        {
            var collTag = collision.tag;
            if (triggerableTags.Contains(collTag))
            {
                colliderTriggerEvents.OnTriggerExitEvent();
            }
        }
        protected virtual void OnTriggerStay2D(Collider2D collision)
        {
            var collTag = collision.tag;
            if (triggerableTags.Contains(collTag))
            {
                colliderTriggerEvents.OnTriggerStayEvent();
            }
        }
        protected virtual void OnCollisionEnter2D(Collision2D collision)
        {
            var collTag = collision.collider.tag;
            if (triggerableTags.Contains(collTag))
            {
                colliderTriggerEvents.OnCollisionEnterEvent();
            }
        }
        protected virtual void OnCollisionStay2D(Collision2D collision)
        {
            var collTag = collision.collider.tag;
            if (triggerableTags.Contains(collTag))
            {
                colliderTriggerEvents.onCollisionStayEvent();
            }
        }
        protected virtual void OnCollisionExit2D(Collision2D collision)
        {
            var collTag = collision.collider.tag;
            if (triggerableTags.Contains(collTag))
            {
                colliderTriggerEvents.OnCollisionExitEvent();
            }
        }
        protected virtual void Awake()
        {
            colliderTriggerEvents = GetComponent<ColliderTriggerEvents>();
        }
    }
}
