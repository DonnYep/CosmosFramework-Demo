using UnityEditor;
using UnityEngine;
namespace Krypton
{
    [CustomEditor(typeof(ColliderTrigger2D))]
    public class ColliderTrigger2DEditor : UnityEditor.Editor
    {
        SerializedObject targetObject;
        ColliderTrigger2D colliderTrigger2D;
        SerializedProperty sp_TriggerableTags;
        SerializedProperty sp_TagsBits;
        int taskBits;
        public override void OnInspectorGUI()
        {
            targetObject.Update();
            EditorGUILayout.BeginVertical();
            {
                EditorGUILayout.HelpBox("��ע�����Ƿ����Collider2D", MessageType.Warning);
                var tags = UnityEditorInternal.InternalEditorUtility.tags;
                EditorGUILayout.BeginHorizontal();
                {
                    GUILayout.Label("TriggerableTags");
                    sp_TagsBits.intValue = EditorGUILayout.MaskField(sp_TagsBits.intValue, tags);
                    if (taskBits != sp_TagsBits.intValue)
                    {
                        taskBits = sp_TagsBits.intValue;
                        sp_TriggerableTags.ClearArray();
                        var tagLength = tags.Length;
                        for (int i = 0; i < tagLength; i++)
                        {
                            var srcCode = sp_TagsBits.intValue;
                            var bitCode = 1 << i;
                            var bit = srcCode & bitCode;
                            if (bit != 0)
                            {
                                sp_TriggerableTags.InsertArrayElementAtIndex(0);
                                sp_TriggerableTags.GetArrayElementAtIndex(0).stringValue = tags[i];
                            }
                        }
                    }
                }
                EditorGUILayout.EndHorizontal();
            }
            EditorGUILayout.EndVertical();
            targetObject.ApplyModifiedProperties();
        }
        private void OnEnable()
        {
            colliderTrigger2D = target as ColliderTrigger2D;
            targetObject = new SerializedObject(colliderTrigger2D);
            sp_TriggerableTags = targetObject.FindProperty("triggerableTags");
            sp_TagsBits = targetObject.FindProperty("tagsBits");

            taskBits = sp_TagsBits.intValue;
        }
    }
}
