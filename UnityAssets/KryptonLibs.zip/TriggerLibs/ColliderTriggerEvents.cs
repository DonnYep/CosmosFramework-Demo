using UnityEngine;
using UnityEngine.Events;

namespace Krypton
{
    [DisallowMultipleComponent]
    public class ColliderTriggerEvents : MonoBehaviour
    {
        [SerializeField] protected UnityEvent onTriggerEnterEvents;
        [SerializeField] protected UnityEvent onTriggerStayEvents;
        [SerializeField] protected UnityEvent onTriggerExitEvents;

        [SerializeField] protected UnityEvent onCollisionEnterEvents;
        [SerializeField] protected UnityEvent onCollisionStayEvents;
        [SerializeField] protected UnityEvent onCollisionExitEvents;

        public UnityEvent OnTriggerEnterEvents
        {
            get { return onTriggerEnterEvents; }
        }
        public UnityEvent OnTriggerStayEvents
        {
            get { return onTriggerStayEvents; }
        }
        public UnityEvent OnTriggerExitEvents
        {
            get { return onTriggerExitEvents; }
        }
        public UnityEvent OnCollisionEnterEvents
        {
            get { return onCollisionEnterEvents; }
        }
        public UnityEvent OnCollisionStayEvents
        {
            get { return onCollisionStayEvents; }
        }
        public UnityEvent OnCollisionExitEvents
        {
            get { return onCollisionExitEvents; }
        }

        public void OnTriggerEnterEvent()
        {
            onTriggerEnterEvents?.Invoke();
        }
        public void OnTriggerStayEvent()
        {
            onTriggerStayEvents?.Invoke();
        }
        public void OnTriggerExitEvent()
        {
            onTriggerExitEvents?.Invoke();
        }
        public void OnCollisionEnterEvent()
        {
            onCollisionEnterEvents?.Invoke();
        }
        public void onCollisionStayEvent()
        {
            onCollisionStayEvents?.Invoke();
        }
        public void OnCollisionExitEvent()
        {
            onCollisionExitEvents?.Invoke();
        }
    }
}
