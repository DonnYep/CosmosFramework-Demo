﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Krypton.QuestSystem
{
    /// <summary>
    /// 任务条件；
    /// </summary>
    public abstract class QuestCondition
    {
        public Quest Quest { get; protected set; }
        public QuestNode QuestNode { get; protected set; }
        /// <summary>
        /// 条件达成回调；
        /// </summary>
        protected Action conditionTrueCallback;
        /// <summary>
        /// 是否检测中；
        /// </summary>
        protected bool isChecking = false;
        public bool IsChecking
        {
            get { return isChecking; }
            set { isChecking = value; }
        }
        public void CheckCondition(QuestNode questNode)
        {

        }
        public virtual void StartChecking(Action conditionTrueCallabck)
        {
            isChecking = true;
            this.conditionTrueCallback = conditionTrueCallabck;
        }
        public virtual void StopChecking()
        {
            isChecking = false;
        }
        public virtual void SetContionTrue()
        {
            StopChecking();

        }
    }
}
