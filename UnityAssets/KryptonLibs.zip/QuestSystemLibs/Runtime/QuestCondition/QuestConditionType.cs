﻿namespace Krypton.QuestSystem
{
    public enum QuestConditionType
    {
        /// <summary>
        /// 消息条件，例如对话
        /// </summary>
        Message,
        /// <summary>
        /// 前置条件，例如存在多个条件，则进入到下一个任务节点时需要满足以上多条件
        /// </summary>
        Parent,
        /// <summary>
        /// 计时条件
        /// </summary>
        Timer,
        /// <summary>
        /// 数量条件，例如寻找指定数量的对象，猎杀怪物等
        /// </summary>
        Counter
    }
}
