﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Krypton.QuestSystem
{
    /// <summary>
    /// 计时任务，需要指定时间内完成任务
    /// </summary>
    public class TimerQuestCondition:QuestCondition
    {
    }
}
