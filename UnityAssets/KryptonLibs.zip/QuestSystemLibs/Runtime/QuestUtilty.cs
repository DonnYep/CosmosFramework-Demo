﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Krypton.QuestSystem
{
    /// <summary>
    /// 任务工具类
    /// </summary>
    public class QuestUtilty
    {
    }
}
