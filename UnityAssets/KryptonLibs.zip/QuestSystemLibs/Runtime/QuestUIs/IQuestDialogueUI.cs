﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Krypton.QuestSystem
{
    /// <summary>
    /// 任务对话系统；
    /// </summary>
    public interface IQuestDialogueUI
    {
        bool IsVisible { get; set; }
    }
}
