﻿using System;

namespace Krypton.QuestSystem
{
    /// <summary>
    /// 任务数据；
    /// </summary>
    [Serializable]
    public class QuestData
    {
        /// <summary>
        /// 任务的唯一id
        /// </summary>
        public string QuestId;
        /// <summary>
        /// 任务名
        /// </summary>
        public string QuestName;
        /// <summary>
        /// 任务内文本
        /// </summary>
        public string QuestContext;
        /// <summary>
        /// 上一个任务id
        /// </summary>
        public string PreviouseQuestId;
        /// <summary>
        /// 下一个任务id
        /// </summary>
        public string NextQuestId;
    }
}
