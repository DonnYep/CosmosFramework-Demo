﻿namespace Krypton.QuestSystem
{
    public interface IQuestDataHelper
    {
        QuestData LoadData();
        void SaveData();
    }
}
