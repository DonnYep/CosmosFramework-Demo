using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
namespace Krypton.QuestSystem
{
    public class QuestManager : MonoBehaviour
    {
        /// <summary>
        /// 任务完成；
        /// </summary>
        Action<Quest> onQuestSuccess;
        /// <summary>
        /// 任务开始
        /// </summary>
        Action<Quest> onQuestStart;
        /// <summary>
        /// 任务失败；
        /// </summary>
        Action<Quest> onQuestFailure;
        /// <summary>
        /// 任务放弃；
        /// </summary>
        Action<Quest> onQuestAbort;
        public event Action<Quest> OnQuestSuccess
        {
            add { onQuestSuccess += value; }
            remove { onQuestSuccess -= value; }
        }
        public event Action<Quest> OnQuestStart
        {
            add { onQuestStart += value; }
            remove { onQuestStart -= value; }
        }
        public event Action<Quest> OnQuestFailure
        {
            add { onQuestFailure += value; }
            remove { onQuestFailure -= value; }
        }
        public event Action<Quest> OnQuestAbort
        {
            add { onQuestAbort += value; }
            remove { onQuestAbort -= value; }
        }
        public void StartQuest(string id)
        {

        }
        public void FinishQuest(string id)
        {

        }
        public void SaveQuest(string questId, Quest quest)
        {

        }
    }
}