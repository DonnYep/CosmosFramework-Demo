namespace Krypton.QuestSystem
{
    public enum QuestState
    {
        /// <summary>
        /// 等待开启
        /// </summary>
        WaitingToStart,
        /// <summary>
        /// 开启中
        /// </summary>
        Active,
        /// <summary>
        /// 任务成功
        /// </summary>
        Successful,
        /// <summary>
        /// 任务失败
        /// </summary>
        Failed,
        /// <summary>
        /// 任务放弃
        /// </summary>
        Abandoned,
        /// <summary>
        /// 任务失效
        /// </summary>
        Disabled
    }
}
