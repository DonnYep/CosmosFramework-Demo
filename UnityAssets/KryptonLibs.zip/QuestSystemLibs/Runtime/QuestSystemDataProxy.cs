﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Krypton.QuestSystem
{
    /// <summary>
    /// 任务runtime持久化数据
    /// </summary>
    public class QuestSystemDataProxy
    {
        static IQuestDataHelper questDataHelper;
        static Dictionary<string, QuestData> questDataDict
            = new Dictionary<string, QuestData>();

        static Dictionary<string, QuestNode> questNodeDict
            = new Dictionary<string, QuestNode>();
        public static bool PeekQuest(string questId, out QuestNode questNode)
        {
            return questNodeDict.TryGetValue(questId, out questNode);
        }
    }
}
