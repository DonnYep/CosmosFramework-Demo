﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Krypton.QuestSystem
{
    public abstract class QuestLogic
    {
        public abstract void OnAccept();
        public abstract void OnActive();
        public abstract void OnProgress();
        public abstract void OnComplete();
        public abstract void OnFailure();
    }
}
