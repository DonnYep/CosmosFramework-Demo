﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace Krypton.QuestSystem
{
    /// <summary>
    /// 任务节点；
    /// </summary>
    public class QuestNode
    {
        public QuestNodeType QuestNodeType;

        public QuestState QuestState;

        QuestData questData;
        public QuestData QuestData
        {
            get { return questData; }
        }

        public QuestStateInfo GetQuestNodeState()
        {
            return default;
        }
        public void LoadData()
        {

        }
    }
}
