﻿namespace Krypton.QuestSystem
{
    public enum QuestNodeType
    {
        /// <summary>
        ///开始节点
        /// </summary>
        Start,
        /// <summary>
        /// 成功节点
        /// </summary>
        Success,
        /// <summary>
        /// 失败节点
        /// </summary>
        Failure,
        /// <summary>
        /// 过场节点
        /// </summary>
        Passthrough,
        /// <summary>
        /// 条件节点
        /// </summary>
        Condition
    }
}
