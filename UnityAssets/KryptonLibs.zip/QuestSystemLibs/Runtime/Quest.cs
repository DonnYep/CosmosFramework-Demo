using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Krypton.QuestSystem
{
    public class Quest
    {
        /// <summary>
        /// ��ǰ��Ծ������㣻
        /// </summary>
        QuestNode currentNode;
        /// <summary>
        /// ��ǰ����״̬��
        /// </summary>
        QuestState questState;
        public QuestNode CurrentNode
        {
            get { return currentNode; }
        }
        public QuestState QuestState
        {
            get { return questState; }
            set { questState = value; }
        }
        public void AcceptQuest(string questId)
        {
            if (QuestSystemDataProxy.PeekQuest(questId, out var node))
            {
            }
        }
    }
}
