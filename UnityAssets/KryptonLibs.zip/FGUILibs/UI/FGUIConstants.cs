﻿namespace Krypton
{
    public class FGUIConstants
    {
        public readonly static string[] SplitSeparator = new string[] { ".", "/", "\\" };
        public readonly static string[] EmptyStringArray = new string[] { };
    }
}
