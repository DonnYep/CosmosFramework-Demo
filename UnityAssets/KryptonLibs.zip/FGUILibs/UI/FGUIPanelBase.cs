﻿using FairyGUI;

namespace Krypton
{
    //================================================
    /*
     * 1、IUIPanel的生命周期类似MonoBehaviour，生命周期顺序为
     *  OnInit-> OnOpen->OnShow->OnClose->OnHide->OnRelease
     *  
     * 2、当IUIPanel被首次开启时，触发OnInit与OnOpen，对应MonoBehaviour
     *  的Awake与OnEnable。
     *  
     * 3、当IUIPanel被打开时，触发OnOpen，对应MonoBehaviour的OnEnable。
     * 
     * 4、当IUIPanel触发OnOpen，FGUI自身的生命周期会调用OnShow。
     * 
     * 5、当IUIPanel被关闭时，触发OnClose，对应MonoBehaviour的OnDisable
     * 
     * 6、当IUIPanel触发OnClose，FGUI自身的生命周期会调用OnHide。
     * 
     * 7、当IUIPanel被释放时，触发OnClose与OnRelease，对应MonoBehaviour
     * 的OnDisable与OnDestroy。
     */
    //================================================
    public abstract class FGUIPanelBase : IUIPanel, IFGUIWindowWrapper
    {
        int sortOrder;
        /// <summary>
        /// 表示FGUI中UIPanel.ui的主渲染对象；
        /// <see cref="FairyGUI.UIPanel.ui"/>
        /// </summary>
        protected Window mainView;
        protected UIPackage uiPackage;
        public UIPackage UIPackage { get { return uiPackage; } set { uiPackage = value; } }
        /// <inheritdoc/>
        public object Handle { get { return mainView; } protected set { mainView = (Window)value; } }
        /// <summary>
        /// FGUI中，一个功能使用一个包体，因此UIAssetName在FGUI的实现中指代一个UI资源包的名；
        /// 如 FGUI官方示例中存在一个Basics包体，Basics可作为UIAssetName的值；
        /// FGUI资源全称。xxx_fui.bytes
        /// </summary>
        public string UIAssetName { get; set; }
        /// <inheritdoc/>
        public virtual int Order
        {
            get { return sortOrder; }
            set { sortOrder = value; }
        }
        /// <inheritdoc/>
        public bool Active { get; set; }
        /// <inheritdoc/>
        public virtual void OnInit()
        {
            var main = uiPackage.CreateObject("Main").asCom;
            mainView = new FGUIWindow(main, this);
            mainView.MakeFullScreen();
        }
        public GObject GetChild(string name)
        {
            return mainView.contentPane.GetChild(name);
        }
        public Controller GetController(string name)
        {
            return mainView.contentPane.GetController(name);
        }
        public Transition GetTransition(string name)
        {
            return mainView.contentPane.GetTransition(name);
        }
        /// <inheritdoc/>
        public virtual void OnOpen() { }
        /// <inheritdoc/>
        public virtual void OnUpdate() { }
        /// <inheritdoc/>
        public virtual void OnClose() { }
        /// <inheritdoc/>
        public virtual void OnRelease()
        {
            mainView?.Dispose();
        }
        /// <inheritdoc/>
        public virtual void OnOrderChange(int index) { }
        /// <summary>
        /// FGUI的生命周期，面板被fgui生命周期打开
        /// </summary>
        public virtual void OnShow() { }
        /// <summary>
        /// FGUI的生命周期，面板被fgui生命周期关闭
        /// </summary>
        public virtual void OnHide() { }
        /// <inheritdoc/>
        public virtual void OnLanguageChange() { }
    }
}
