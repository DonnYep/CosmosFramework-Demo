using FairyGUI;
using Spine.Unity;
using UnityEngine;
using Krypton;

public static class FGUISpineHelper
{
    /// <summary>
    /// 播放spine动画
    /// </summary>
    public static SkeletonAnimation PlaySpineAnimation(GComponent parent, string resName, string aniName, bool isLoop)
    {
        //GGraph graph = parent.GetChild("graph").asGraph;
        //if (graph.displayObject.cachedTransform.childCount > 0)
        //{
        //    SkeletonAnimation aniOld = graph.displayObject.cachedTransform.GetComponentInChildren<SkeletonAnimation>();
        //    aniOld.AnimationState.SetAnimation(0, aniName, isLoop);
        //    return aniOld;
        //}
        //GameObject obj = GameObject.Instantiate(ResourceManager.Instance.LoadPrefab(resName));
        //GoWrapper goWrapper = new GoWrapper(obj);
        //graph.SetNativeObject(goWrapper);
        //obj.transform.localPosition=Vector3.zero;
        //SkeletonAnimation ani = graph.displayObject.cachedTransform.GetComponentInChildren<SkeletonAnimation>();
        //ani.AnimationState.SetAnimation(0, aniName, isLoop);
        //return ani;
        return default;
    }

    public static SkeletonAnimation PlaySpineAnimation(GComponent parent, string resName, string aniName, bool isLoop, ref GoWrapper goWrapper)
    {
        //GGraph graph = parent.GetChild("graph").asGraph;
        //GameObject obj = GameObject.Instantiate(ResourceManager.Instance.LoadPrefab(resName));
        //goWrapper = new GoWrapper(obj);
        //graph.SetNativeObject(goWrapper);
        //obj.transform.localPosition = Vector3.zero;
        //SkeletonAnimation ani = graph.displayObject.cachedTransform.GetComponentInChildren<SkeletonAnimation>();
        //ani.AnimationState.SetAnimation(0, aniName, isLoop);
        //return ani;
        return default;
    }
}
