using FairyGUI;

namespace Krypton
{
    public interface IFGUIWindowWrapper
    {
        public void OnShow();
        public void OnHide();
    }
    public class FGUIWindow : Window
    {
        protected IFGUIWindowWrapper window;
        public FGUIWindow(GComponent contentPane, IFGUIWindowWrapper window = null)
                   : base()
        {
            this.window = window;
            this.contentPane = contentPane;
        }
        protected override void OnShown()
        {
            window?.OnShow();
        }
        protected override void OnHide()
        {
            window?.OnHide();
        }
    }
}