﻿using System;
using UnityEngine;
using FairyGUI;

namespace Krypton
{
    //================================================
    /*
     * 1、FGUI中，一个"_fui"的资源表示为一个面板，等价于UGUI中做成prefab
     * 的ui面板。
     * 
     * 2、FGUI的资源体的文件都以_fui结尾，后缀名为 .bytes 。
     * 
     * 3、FGUI的一个Panel在此视为一个UIPackage。所属于这个UIPackage
     * 的子组件都归属于这个Panel管理。在MVC架构之下，Panel内的具体业务
     * 逻辑由View层管理。
     * 
     * 4、与UGUI的区别。UGUI中，一个面板可以作为一个预制体(prefab)存在，
     * 与之所属的子组件都由这个面板本身管理，例如按钮按下逻辑，图片显示
     * 逻辑等。在MVC架构之下，则由View层管理具体的业务处理，面板只负责
     * 数据显示与更新。
     * 
     * 5、Quark环境下，FGUI加载时UIAssetInfo.UIAssetName表示xxx_fui.bytes
     * 的包体。包内的component组件、图片、字体等都由UIPanel自行维护。
     * 
     * 6、当UIPackage中存在多个渲染组件，并且需要将渲染组件作为Panel
     * 管理时，可以使用#UIAssetName.Comp#的格式作为UIAssetName名。
     * 详见案例: 02_UGUI&FGUI 场景。
     */
    //================================================
    public class FGUIAssetHelper : IUIAssetHelper
    {
        /// <summary>
        /// fgui文件的后缀
        /// </summary>
        readonly string fguiSuffix = "_fui";
        public FGUIAssetHelper()
        {
            Stage.inst.gameObject.transform.SetParent(UIManager.InstanceObject.transform);
        }
        public IUIPanel LoadUIPanel(Type uiType, UIAssetInfo assetInfo)
        {
            //Quark中，fugi的资源包是以xxx_fui.bytes形式存在的；
            //补全资源包的完整信息。补全信息格式参考：xxx_fui
            FGUIPanelBase fguiPanel = default;
            var uiAssetName = assetInfo.UIAssetName;
            var uiSplitedNames = GetSplitedName(uiAssetName);
            var uiPackageName = uiSplitedNames[0];
            var package = UIPackage.GetByName(uiPackageName);
            if (package == null)
            {
                //添加包体，生成UIPackage
                package = UIPackage.AddPackage(uiPackageName, LoadFGUIAsset);
                if (package == null)
                {
                    Utility.Debug.LogError($"资源无法寻址 : {assetInfo}");
                    return null;
                }
                //反射生成FGUI实例
                fguiPanel = Activator.CreateInstance(uiType) as FGUIPanelBase;

                //设置包体
                fguiPanel.UIPackage = package;
                fguiPanel.UIAssetName = uiAssetName;
                //触发回调
                return fguiPanel;
            }
            else
            {
                //反射生成FGUI实例
                fguiPanel = Activator.CreateInstance(uiType) as FGUIPanelBase;
                //设置包体
                fguiPanel.UIPackage = package;
                fguiPanel.UIAssetName = uiAssetName;
                //触发回调
                return fguiPanel;
            }
        }
        public AsyncOperationHandle LoadUIPanelAsync(Type uiType, UIAssetInfo assetInfo, Action<IUIPanel> callback)
        {
            FGUIPanelBase fguiPanel = default;
            var uiAssetName = assetInfo.UIAssetName;
            var uiSplitedNames = GetSplitedName(uiAssetName);
            var uiPackageName = uiSplitedNames[0];
            var package = UIPackage.GetByName(uiPackageName);
            if (package == null)
            {
                //添加包体，生成UIPackage
                package = UIPackage.AddPackage(uiPackageName, LoadFGUIAsset);
                if (package == null)
                {
                    Utility.Debug.LogError($"资源无法寻址 : {assetInfo}");
                    return default;
                }
                //反射生成FGUI实例
                fguiPanel = Activator.CreateInstance(uiType) as FGUIPanelBase;
                //设置包体
                fguiPanel.UIPackage = package;
                fguiPanel.UIAssetName = uiAssetName;
                //触发回调
                callback?.Invoke(fguiPanel);
                return default;
            }
            else
            {
                fguiPanel = Activator.CreateInstance(uiType) as FGUIPanelBase;
                //设置包体
                fguiPanel.UIPackage = package;
                fguiPanel.UIAssetName = uiAssetName;
                //触发回调
                callback?.Invoke(fguiPanel);
            }
            return default;
        }
        public void ReleaseUIPanel(IUIPanel panel)
        {
            //补全FGUI资源名称，补全后FGUI资源包为xxx_fui格式
            var uiAssetName = panel.UIAssetName;
            var uiSplitedNames = GetSplitedName(uiAssetName);
            var uiPackageName = uiSplitedNames[0];
            var fullFguiPackName = Utility.Text.Append(uiPackageName, fguiSuffix);
            var package = UIPackage.GetByName(uiPackageName);
            if (package == null)
                return;
            var handle = panel.Handle.As<GComponent>();
            GRoot.inst.RemoveChild(handle);
            if (handle != null)
            {
                var go = handle.displayObject.gameObject;
                GameObject.Destroy(go);
            }
            //这里释放资源体，Quark会自行维护资源的引用计数。
            //所有的资源引用计数都可被查询。
            ResourceManager.Instance.UnloadAsset(fullFguiPackName);
            var has = ResourceManager.Instance.GetResourceInfo(fullFguiPackName, out var info);
            if (has)
            {
                if (info.ReferenceCount == 0)
                {
                    package.UnloadAssets();
                    UIPackage.RemovePackage(uiPackageName);
                }
            }
            else
            {
                package.UnloadAssets();
                UIPackage.RemovePackage(uiPackageName);
            }
        }
        public static object LoadFGUIAsset(string name, string extension, Type type, out DestroyMethod destroyMethod)
        {
            Type resType = default;
            if (type == typeof(UnityEngine.Texture))
                resType = typeof(Texture2D);
            else
                resType = type;
            destroyMethod = DestroyMethod.Custom;
            //var res = ResourceManager.Instance.LoadAsset(name, resType);
            //return res;
            return default;
        }
        string[] GetSplitedName(string path)
        {
            if (string.IsNullOrEmpty(path))
            {
                return FGUIConstants.EmptyStringArray;
            }
            return path.Split(FGUIConstants.SplitSeparator, StringSplitOptions.RemoveEmptyEntries);
        }
    }
}
