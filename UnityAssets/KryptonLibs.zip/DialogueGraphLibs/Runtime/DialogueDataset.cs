using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
 namespace Dialogue
{
    /// <summary>
    /// �Ի����ݣ�
    /// </summary>
    [Serializable]
    public class DialogueDataset: ScriptableObject
    {

    }
}