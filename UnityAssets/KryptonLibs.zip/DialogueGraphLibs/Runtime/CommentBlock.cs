﻿using System;
using System.Collections.Generic;
using UnityEngine;
namespace Dialogue
{
    [Serializable]
    public class CommentBlock
    {
        public string Title = "Comment Block";
        public List<string> ChildNodes = new List<string>();
        public Vector2 Position;
    }
}
