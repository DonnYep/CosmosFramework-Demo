﻿using System;
using UnityEngine;
namespace Dialogue
{
    [Serializable]
    public class DialogueNodeData
    {
        public string NodeGuid;
        public string DialogueText;
        public Vector2 Position;
    }
}
