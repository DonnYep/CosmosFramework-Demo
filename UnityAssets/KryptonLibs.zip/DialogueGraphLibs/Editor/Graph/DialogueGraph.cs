using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;
using UnityEditor.Experimental.GraphView;
using UnityEditor;
using UnityEditor.UIElements;

namespace Dialogue.Graph
{
    public class DialogueGraph : EditorWindow
    {

        [MenuItem("Window/DialogueGraph")]
        public static void OpenWindow()
        {
            var window = GetWindow<DialogueGraph>();
            window.titleContent = new GUIContent("DialogueGraph");
        }
        DialogueGraphView graphView;
        private void OnEnable()
        {
            ConstructGraphView();
            GenerateToorBar();
        }
        private void OnDisable()
        {
            rootVisualElement.Remove(graphView);
        }
        void GenerateToorBar()
        {
            var toolbar = new Toolbar();
            var nodeCreateButton = new Button(() =>
            {
                graphView.CreateNode("Dialogue Node");
            });
            nodeCreateButton.text = "Create Node";
            toolbar.Add(nodeCreateButton);
            rootVisualElement.Add(toolbar);
        }
        void ConstructGraphView()
        {
            graphView = new DialogueGraphView()
            {
                name = "DialogueGraph"
            };
            graphView.StretchToParentSize();
            rootVisualElement.Add(graphView);
        }
    }
}