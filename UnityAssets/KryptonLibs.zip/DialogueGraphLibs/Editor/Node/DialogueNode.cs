using UnityEditor.Experimental.GraphView;
namespace Dialogue.Graph
{
    public class DialogueNode : Node
    {
        public string Guid;
        public string DialgueText;
        public bool EntryPoint = false;
    }
}
