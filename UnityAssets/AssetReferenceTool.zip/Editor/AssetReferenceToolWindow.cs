using Krypton;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;

public class AssetReferenceToolWindow : EditorWindow
{
    [MenuItem("Window/����Ϸ�����ض�λ����")]
    public static void ShowWindow()
    {
        GetWindow<AssetReferenceToolWindow>("����Ϸ�����ض�λ����");
    }
    UnityEngine.Object srcDefaultAsset = null;
    UnityEngine.Object dstDefaultAsset = null;
    AssetReferenceToolData wndData;
    internal const string DataName = "AssetReferenceToolData.json";
    AssetTreeLabel assetTreeLabel = new AssetTreeLabel();

    private void OnEnable()
    {
        try
        {
            wndData = Krypton.Editor.EditorUtil.GetData<AssetReferenceToolData>(DataName);
            dstDefaultAsset = AssetDatabase.LoadAssetAtPath<DefaultAsset>(wndData.DstFolderPath);
            srcDefaultAsset = AssetDatabase.LoadAssetAtPath<DefaultAsset>(wndData.SrcFolderPath);
        }
        catch
        {
            wndData = new AssetReferenceToolData();
            Krypton.Editor.EditorUtil.SaveData(DataName, wndData);
        }
        assetTreeLabel.OnEnable();
        if (!string.IsNullOrEmpty(wndData.DstFolderPath))
        {
            ScanPrefabAndScene();
        }
    }
    private void OnGUI()
    {
        DrawFolderField();
        assetTreeLabel.OnGUI(position);


        EditorGUILayout.BeginHorizontal();
        {
            GUILayout.FlexibleSpace();
            ProcessPrefabReference();
        }
        EditorGUILayout.EndHorizontal();
        EditorGUILayout.Space(16);
    }
    private void OnDisable()
    {
        Krypton.Editor.EditorUtil.SaveData(DataName, wndData);
    }
    void DrawFolderField()
    {
        GUILayout.Space(24);

        EditorGUI.BeginChangeCheck();
        srcDefaultAsset = EditorGUILayout.ObjectField("ԭʼĿ¼", srcDefaultAsset, typeof(DefaultAsset), false);
        if (EditorGUI.EndChangeCheck())
        {
            if (srcDefaultAsset != null)
            {
                var path = AssetDatabase.GetAssetPath(srcDefaultAsset);
                wndData.SrcFolderPath = path;
            }
        }

        EditorGUI.BeginChangeCheck();
        dstDefaultAsset = EditorGUILayout.ObjectField("Ŀ��Ŀ¼", dstDefaultAsset, typeof(DefaultAsset), false);
        if (EditorGUI.EndChangeCheck())
        {
            if (dstDefaultAsset != null)
            {
                var path = AssetDatabase.GetAssetPath(dstDefaultAsset);
                wndData.DstFolderPath = path;
            }
        }

        GUILayout.Space(16);

        EditorGUILayout.BeginHorizontal();
        {
            if (GUILayout.Button("Scan", GUILayout.MaxWidth(position.width / 2)))
            {
                ScanPrefabAndScene();
            }
            if (GUILayout.Button("Clear", GUILayout.MaxWidth(position.width / 2)))
            {
                dstDefaultAsset = null;
                srcDefaultAsset = null;
                wndData.DstFolderPath = string.Empty;
                wndData.SrcFolderPath = string.Empty;
                assetTreeLabel.ClearTreeView();
            }
            EditorGUILayout.EndHorizontal();

            GUILayout.Space(16);

            EditorGUILayout.BeginVertical();
            {
                using (var scope = new EditorGUILayout.HorizontalScope(EditorStyles.toolbar))
                {
                    EditorGUILayout.LabelField($"AssetCount: {assetTreeLabel.AssetCount}", EditorStyles.boldLabel);
                }
            }
            EditorGUILayout.EndVertical();
        }
    }
    /// <summary>
    /// ��������
    /// </summary>
    void ProcessPrefabReference()
    {
        if (GUILayout.Button("Replace guid", GUILayout.MaxWidth(256)))
        {
            if (srcDefaultAsset == null)
            {
                Krypton.Utility.Debug.LogError("��ѡ��ԭʼĿ¼");
                return;
            }

            AssetUtility.ReplaceAllGuid(wndData.SrcFolderPath, wndData.DstFolderPath);
        }
        if (GUILayout.Button("Clear tree view", GUILayout.MaxWidth(256)))
        {
            assetTreeLabel.ClearTreeView();
        }
    }
    void ScanPrefabAndScene()
    {
        assetTreeLabel.ClearTreeView();
        if (string.IsNullOrEmpty(wndData.DstFolderPath))
        {
            return;
        }
        Krypton.Editor.EditorUtil.Coroutine.StartCoroutine(ScanDstFolderAsset());
    }
    IEnumerator ScanDstFolderAsset()
    {
        var unityFolderPath = wndData.DstFolderPath;
        var appPath = Krypton.Editor.EditorUtil.ApplicationPath();
        var folderPath = Utility.IO.WebPathCombine(appPath, unityFolderPath);
        var assetList = Utility.IO.GetAllFilesExceptExtensions(folderPath, AssetUtility.ExceptExts);
        float assetCount = assetList.Count;
        int index = 0;
        foreach (string assetPath in assetList)
        {
            index++;
            if (assetPath.Contains(".git"))
                continue;
            var formatedPath = assetPath.Replace("\\", "/");
            string pathInUnity = formatedPath.Remove(0, appPath.Length + 1);
            var relativePath = pathInUnity.Remove(0, unityFolderPath.Length + 1);
            var ext = Path.GetExtension(formatedPath);
            var info = new AssetReferenceInfo(pathInUnity, ext, relativePath);
            assetTreeLabel.AddInfo(info);
            EditorUtility.DisplayCancelableProgressBar("ReplaceGuid", $"scanning target {index}/{assetCount}", index / assetCount);
        }
        EditorUtility.ClearProgressBar();
        yield return null;
        assetTreeLabel.RefreshTreeView();
    }
}
