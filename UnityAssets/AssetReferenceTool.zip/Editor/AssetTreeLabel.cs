﻿using UnityEditor.IMGUI.Controls;
using UnityEngine;

public class AssetTreeLabel
{
    AssetTreeView treeView;
    TreeViewState treeViewState;
    SearchField searchField;
    public int AssetCount { get { return treeView.AssetCount; } }
    public void OnEnable()
    {
        searchField = new SearchField();
        treeViewState = new TreeViewState();
        var multiColumnHeaderState = new MultiColumnHeader(AssetUtility.CreateAssetTreeMultiColumnHeader());
        treeView = new AssetTreeView(treeViewState, multiColumnHeaderState);
        searchField.downOrUpArrowKeyPressed += treeView.SetFocusAndEnsureSelectedItem;
    }
    public void OnGUI(Rect rect)
    {
        DrawTreeView(rect);
    }
    public void ClearTreeView()
    {
        treeView.ClearTreeView();
    }
    public void AddInfo(AssetReferenceInfo info)
    {
        treeView.AddInfo(info);
    }
    public void RefreshTreeView()
    {
        treeView.Reload();
    }
    void DrawTreeView(Rect rect)
    {
        GUILayout.BeginVertical(GUILayout.Width(rect.width));
        {
            treeView.searchString = searchField.OnToolbarGUI(treeView.searchString);
            Rect viewRect = GUILayoutUtility.GetRect(32, 8192, 32, 8192);
            treeView.OnGUI(viewRect);
        }
        GUILayout.EndVertical();
    }
}
