﻿using Krypton;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.IMGUI.Controls;
using UnityEngine;

/*==========================================================
 * 定义：原始文件目录A=Src，拷贝出来的文件目录B=Dst
 * 
 * 扫描并缓存Src目录内的所有meta文件路径
 * 
 * 扫描并缓存Dst目录内除asmdef，dll的所有文件路径
 * 
 * 通常子游戏有独立的asmdef，asmdef内的cs脚本可能会与平级子游戏的脚本命名重复，但是只要能够通过编译，就应能正常运行。
 * 子游戏在由母本拷贝复制后，资产的索引会指向母本内的资源，这本身在unity的逻辑中是合理的，
 * 但是我们需要的是能够在从母本复制后，内部的引用指向新目录下的资产。
 * 
 ==========================================================*/
public class AssetUtility
{
    /// <summary>
    /// 过滤忽略的后缀类型
    /// </summary>
    public readonly static string[] ExceptExts = new string[]
    {
        ".asmdef",
        ".dll",
        ".meta",
        ".cs",
        ".txt",
        ".png",
        ".mp3",
        ".md",
        ".fbx",
        ".json",
        "dds",
        ".tga",
        ".swatch",
        ".anim",
        ".bytes",
        ".shader",
        ".ttf",
        ".otf",
        ".jpg"
    };

    /// 获取标签过滤icon
    /// </summary>
    /// <returns>标签过滤icon</returns>
    public static Texture2D GetFilterByTypeIcon()
    {
        return EditorGUIUtility.FindTexture("FilterByType");
    }
    /// <summary>
    /// 获取treeview的header配置
    /// </summary>
    /// <returns>treeview的header配置</returns>
    public static MultiColumnHeaderState CreateAssetTreeMultiColumnHeader()
    {
        var columns = new[]
        {
                new MultiColumnHeaderState.Column
                {
                    headerContent = new GUIContent(GetFilterByTypeIcon()),
                    headerTextAlignment = TextAlignment.Center,
                    sortingArrowAlignment = TextAlignment.Center,
                    sortedAscending = false,
                    minWidth=32,
                    width=32,
                    maxWidth=32,
                    autoResize = true,
                },
                new MultiColumnHeaderState.Column
                {
                    headerContent = new GUIContent("Asset"),
                    headerTextAlignment = TextAlignment.Left,
                    sortingArrowAlignment = TextAlignment.Left,
                    sortedAscending = false,
                    minWidth=512,
                    width=768,
                    maxWidth=1920,
                    autoResize = true,
                }
            };
        var state = new MultiColumnHeaderState(columns);
        return state;
    }
    public static void ReplaceAllGuid(string srcFolder, string dstFolder)
    {
        var appPath = Krypton.Editor.EditorUtil.ApplicationPath();
        var srcDir = Utility.IO.WebPathCombine(appPath, srcFolder);
        var dstDir = Utility.IO.WebPathCombine(appPath, dstFolder);
        try
        {
            Krypton.Editor.EditorUtil.Coroutine.StartCoroutine(RunReplaceGUIDsInFolder(srcDir, dstDir));
        }
        catch (System.Exception e)
        {
            EditorUtility.ClearProgressBar();
            throw e;
        }
    }
    private static IEnumerator RunReplaceGUIDsInFolder(string source, string target)
    {
        Dictionary<string, string> guidMap = new Dictionary<string, string>();
        var srcMetaList = Utility.IO.GetAllFiles(source, "*.meta");
        var dstMetaList = Utility.IO.GetAllFilesExceptExtensions(target, ".asmdef", ".dll");
        int srcIndex = 0;
        float srcLength = srcMetaList.Length;

        float dstLength = dstMetaList.Count;
        foreach (var file in srcMetaList)
        {
            srcIndex++;
            EditorUtility.DisplayCancelableProgressBar("ReplaceGuid", $"scanning source {srcIndex}/{srcLength}", srcIndex / srcLength);
            string oldGUID = GetGuidFromMate(file);
            string newFile = file.Replace(source, target);
            string newGUID = GetGuidFromMate(newFile);
            if (string.IsNullOrEmpty(oldGUID) || string.IsNullOrEmpty(newGUID))
                Debug.LogError($"{file}: {oldGUID} => {newGUID}");
            guidMap[oldGUID] = newGUID;
        }
        yield return null;
        int dstIndex = 0;
        foreach (var file in dstMetaList)
        {
            dstIndex++;
            EditorUtility.DisplayCancelableProgressBar("ReplaceGuid", $"replacing target {dstIndex }/{dstLength}", dstIndex / dstLength);

            bool bFind = false;
            if (!file.EndsWith(".meta"))
            {
                string content = File.ReadAllText(file);
                foreach (var kvp in guidMap)
                {
                    if (content.Contains(kvp.Key))
                    {
                        bFind = true;
                        content = content.Replace(kvp.Key, kvp.Value);
                    }
                }
                if (bFind)
                {
                    File.WriteAllText(file, content);
                }
            }
        }
        yield return null;
        EditorUtility.ClearProgressBar();
        Krypton.Editor.EditorUtil.Debug.LogInfo("GUID 替换完成！");
    }
    private static string GetGuidFromMate(string file)
    {
        if (!file.EndsWith(".meta"))
            return "";
        string metaContent = File.ReadAllText(file);
        string guidLine = metaContent.Split('\n')[1];
        return guidLine.Replace("guid: ", "").Trim();
    }
}
