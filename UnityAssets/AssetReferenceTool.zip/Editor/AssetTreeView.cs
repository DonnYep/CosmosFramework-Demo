﻿using System.Collections.Generic;
using UnityEditor;
using UnityEditor.IMGUI.Controls;
using UnityEngine;

public class AssetTreeView : TreeView
{
    readonly List<AssetReferenceInfo> assetInfoList = new List<AssetReferenceInfo>();
    public int AssetCount { get { return assetInfoList.Count; } }
    public AssetTreeView(TreeViewState treeViewState, MultiColumnHeader multiColumnHeader)
: base(treeViewState, multiColumnHeader)
    {
        Reload();
        showAlternatingRowBackgrounds = true;
        showBorder = true;
        multiColumnHeader.sortingChanged += OnMultiColumnHeaderSortingChanged;
    }
    public void AddInfo(AssetReferenceInfo assetReferenceInfo)
    {
        if (!assetInfoList.Contains(assetReferenceInfo))
        {
            assetInfoList.Add(assetReferenceInfo);
        }
    }
    public void ClearTreeView()
    {
        assetInfoList.Clear();
        Reload();

    }
    protected override TreeViewItem BuildRoot()
    {
        var root = new TreeViewItem { id = -1, depth = -1, displayName = "Root" };
        var allItems = new List<TreeViewItem>();
        for (int i = 0; i < assetInfoList.Count; i++)
        {
            var assetInfo = assetInfoList[i];
            var assetIcon = AssetDatabase.GetCachedIcon(assetInfo.AssetPath) as Texture2D;
            var item = new TreeViewItem(i, 1, assetInfo.AssetPath)
            {
                icon = assetIcon
            };
            allItems.Add(item);
        }
        SetupParentsAndChildrenFromDepths(root, allItems);
        return root;
    }
    protected override void SingleClickedItem(int id)
    {
        base.SingleClickedItem(id);
        Krypton.Editor.EditorUtil.ActiveObject(assetInfoList[id].AssetPath);
    }
    protected override void DoubleClickedItem(int id)
    {
        base.DoubleClickedItem(id);
        Krypton.Editor.EditorUtil.PingAndActiveObject(assetInfoList[id].AssetPath);
    }
    protected override void RowGUI(RowGUIArgs args)
    {
        var length = args.GetNumVisibleColumns();
        for (int i = 0; i < length; i++)
        {
            DrawCellGUI(args.GetCellRect(i), args.item, args.GetColumn(i), ref args);
        }
    }
    void DrawCellGUI(Rect cellRect, TreeViewItem treeView, int column, ref RowGUIArgs args)
    {
        switch (column)
        {
            case 0:
                {
                    var iconRect = new Rect(cellRect.x + 8, cellRect.y, cellRect.height, cellRect.height);
                    if (treeView.icon != null)
                        GUI.DrawTexture(iconRect, treeView.icon, ScaleMode.ScaleToFit);
                }
                break;
            case 1:
                {
                    DefaultGUI.Label(cellRect, treeView.displayName, args.selected, args.focused);
                }
                break;
        }
    }
    void OnMultiColumnHeaderSortingChanged(MultiColumnHeader multiColumnHeader)
    {
        var sortedColumns = multiColumnHeader.state.sortedColumns;
        if (sortedColumns.Length == 0)
            return;
        var sortedType = sortedColumns[0];
        var ascending = multiColumnHeader.IsSortedAscending(sortedType);
        switch (sortedType)
        {
            case 0://icon
                {
                    if (ascending)
                        assetInfoList.Sort((lhs, rhs) => lhs.AssetExtension.CompareTo(rhs.AssetExtension));
                    else
                        assetInfoList.Sort((lhs, rhs) => rhs.AssetExtension.CompareTo(lhs.AssetExtension));
                }
                break;
            case 1://AssetPath
                {
                    if (ascending)
                        assetInfoList.Sort((lhs, rhs) => lhs.AssetPath.CompareTo(rhs.AssetPath));
                    else
                        assetInfoList.Sort((lhs, rhs) => rhs.AssetPath.CompareTo(lhs.AssetPath));
                }
                break;
        }
        Reload();
    }
}
