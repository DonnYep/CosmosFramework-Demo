﻿public class AssetReferenceToolData
{
    /// <summary>
    /// 原始根目录
    /// </summary>
    public string SrcFolderPath;
    /// <summary>
    /// 目标根目录
    /// </summary>
    public string DstFolderPath;
}
