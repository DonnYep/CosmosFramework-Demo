﻿using System;
/// <summary>
/// 场景或预制体信息
/// </summary>
public struct AssetReferenceInfo : IEquatable<AssetReferenceInfo>
{
    /// <summary>
    /// 资产地址
    /// </summary>
    public string AssetPath;
    /// <summary>
    /// 资产后缀名
    /// </summary>
    public string AssetExtension;
    /// <summary>
    /// 根目录下的相对路径
    /// </summary>
    public string AssetRelativePath;
    public AssetReferenceInfo(string assetPath,string assetExtension, string assetRelativePath)
    {
        AssetPath = assetPath;
        AssetRelativePath = assetRelativePath;
        AssetExtension = assetExtension;
    }
    public bool Equals(AssetReferenceInfo other)
    {
        return other.AssetPath == AssetPath &&
            other.AssetExtension==AssetExtension&&
            other.AssetRelativePath == AssetRelativePath;
    }
}
