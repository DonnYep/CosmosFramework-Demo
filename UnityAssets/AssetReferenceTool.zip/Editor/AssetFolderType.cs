﻿public enum AssetFolderType
{
    /// <summary>
    /// 原始目录
    /// </summary>
    SRC,
    /// <summary>
    /// 拷贝出来的目录
    /// </summary>
    DST,
}
