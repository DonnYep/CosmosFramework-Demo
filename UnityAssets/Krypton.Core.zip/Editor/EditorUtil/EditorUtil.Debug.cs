﻿using Object = UnityEngine.Object;
namespace Krypton.Editor
{
    public static partial class EditorUtil
    {
        public static class Debug
        {
            public static void LogInfo(object msg, DebugColor logColor = DebugColor.cyan)
            {
                UnityEngine.Debug.Log($"<b><color={logColor}>{"[INFO]-->>"}</color></b>{msg}");
            }
            public static void LogInfo(object msg, Object context, DebugColor logColor = DebugColor.cyan)
            {
                UnityEngine.Debug.Log($"<b><color={logColor}>{"[INFO]-->>"}</color></b>{msg}", context);
            }
            public static void LogWarning(object msg)
            {
                UnityEngine.Debug.LogWarning($"<b><color={DebugColor.orange}>{"[WARNING]-->>" }</color></b>{msg}");
            }
            public static void LogWarning(object msg, Object context)
            {
                UnityEngine.Debug.LogWarning($"<b><color={DebugColor.orange}>{"[WARNING]-->>" }</color></b>{msg}", context);
            }
            public static void LogError(object msg)
            {
                UnityEngine.Debug.LogError($"<b><color={DebugColor.red}>{"[ERROR]-->>"} </color></b>{msg}");
            }
            public static void LogError(object msg, Object context)
            {
                UnityEngine.Debug.LogError($"<b><color={DebugColor.red}>{"[ERROR]-->>"}</color></b>{msg}", context);
            }
        }
    }
}