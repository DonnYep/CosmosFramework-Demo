﻿using UnityEngine;
using UnityEditor;
using System;

namespace Krypton.Editor
{
    [CustomEditor(typeof(KryptonAppConfig), false)]
    public class KryptonAppConfigEditor : UnityEditor.Editor
    {
        KryptonAppConfig kryptonConfig;
        SerializedObject targetObject;

        SerializedProperty sp_RunInBackground;
        SerializedProperty sp_MultiTouchEnabled;
        SerializedProperty sp_TargetFrameRate;
        SerializedProperty sp_AppSleepTimeoutType;
        SerializedProperty sp_SleepTimeout;
        SerializedProperty sp_ScreenOrientation;
        SerializedProperty sp_LandscapeRight;
        SerializedProperty sp_LandscapeLeft;
        SerializedProperty sp_Portrait;
        SerializedProperty sp_PortraitUpsideDown;

        int appSleepTimeoutTypeIndex;

        string[] appSleepTimeoutTypeFields;
        public override void OnInspectorGUI()
        {
            targetObject.Update();
            EditorGUILayout.LabelField("Krypton application config", EditorStyles.boldLabel);
            EditorGUILayout.Space(4);
            sp_RunInBackground.boolValue = EditorGUILayout.ToggleLeft("RunInBackground", sp_RunInBackground.boolValue);
            sp_MultiTouchEnabled.boolValue = EditorGUILayout.ToggleLeft("MultiTouchEnabled", sp_MultiTouchEnabled.boolValue);
            sp_TargetFrameRate.intValue = Mathf.RoundToInt(EditorGUILayout.Slider("TargetFrameRate", sp_TargetFrameRate.intValue, 30, 120));
            appSleepTimeoutTypeIndex = EditorGUILayout.Popup("AppSleepTimeoutType", appSleepTimeoutTypeIndex, appSleepTimeoutTypeFields);
            if (appSleepTimeoutTypeIndex != sp_AppSleepTimeoutType.enumValueIndex)
            {
                sp_AppSleepTimeoutType.enumValueIndex = appSleepTimeoutTypeIndex;
            }
            var appSleepTimeoutType = (AppSleepTimeoutType)appSleepTimeoutTypeIndex;
            if (appSleepTimeoutType == AppSleepTimeoutType.CustomeTimeout)
            {
                sp_SleepTimeout.intValue = EditorGUILayout.IntField("SleepTimeout", sp_SleepTimeout.intValue);
            }

            kryptonConfig.screenOrientation = (ScreenOrientation)EditorGUILayout.EnumPopup("Orientation", kryptonConfig.screenOrientation);
            if (kryptonConfig.screenOrientation == ScreenOrientation.AutoRotation)
            {
                sp_Portrait.boolValue = EditorGUILayout.ToggleLeft("Portrait", sp_Portrait.boolValue);
                sp_PortraitUpsideDown.boolValue = EditorGUILayout.ToggleLeft("PortraitUpsideDown", sp_PortraitUpsideDown.boolValue);
                sp_LandscapeRight.boolValue = EditorGUILayout.ToggleLeft("LandscapeRight", sp_LandscapeRight.boolValue);
                sp_LandscapeLeft.boolValue = EditorGUILayout.ToggleLeft("LandscapeLeft", sp_LandscapeLeft.boolValue);
                if (!(sp_PortraitUpsideDown.boolValue| sp_LandscapeRight.boolValue | sp_LandscapeLeft.boolValue))
                {
                    sp_Portrait.boolValue = true;
                }
            }
            targetObject.ApplyModifiedProperties();
        }
        void OnEnable()
        {
            kryptonConfig = target as KryptonAppConfig;
            targetObject = new SerializedObject(kryptonConfig);
            sp_RunInBackground = targetObject.FindProperty("runInBackground");
            sp_MultiTouchEnabled = targetObject.FindProperty("multiTouchEnabled");
            sp_TargetFrameRate = targetObject.FindProperty("targetFrameRate");
            sp_AppSleepTimeoutType = targetObject.FindProperty("appSleepTimeoutType");
            sp_SleepTimeout = targetObject.FindProperty("sleepTimeout");
            sp_ScreenOrientation = targetObject.FindProperty("screenOrientation");
            sp_LandscapeRight = targetObject.FindProperty("landscapeRight");
            sp_LandscapeLeft = targetObject.FindProperty("landscapeLeft");
            sp_Portrait = targetObject.FindProperty("portrait");
            sp_PortraitUpsideDown = targetObject.FindProperty("portraitUpsideDown");
            appSleepTimeoutTypeFields = Enum.GetNames(typeof(AppSleepTimeoutType));
            RefreshConfig();
        }
        void RefreshConfig()
        {
            appSleepTimeoutTypeIndex = sp_AppSleepTimeoutType.enumValueIndex;
        }
    }
}
