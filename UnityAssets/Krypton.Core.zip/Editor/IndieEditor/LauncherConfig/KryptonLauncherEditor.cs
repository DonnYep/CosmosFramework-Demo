﻿using UnityEditor;
using System;
namespace Krypton.Editor
{
    [CustomEditor(typeof(KryptonLauncher), false)]
    public class KryptonLauncherEditor : UnityEditor.Editor
    {
        SerializedObject targetObject;
        KryptonLauncher kryptonLauncher;

        //SerializedProperty sp_ResourceLoaderName;
        //SerializedProperty sp_ResourceLoaderIndex;
        SerializedProperty sp_DrawDebugWindow;
        SerializedProperty sp_DisableDebugLog;

        int resourceLoaderIndex;
        string[] resourceLoaders;
        public override void OnInspectorGUI()
        {
            targetObject.Update();

            EditorGUILayout.LabelField("RuntimeDebugLog", EditorStyles.boldLabel);
            sp_DisableDebugLog.boolValue = EditorGUILayout.ToggleLeft("DisableDebugLog", sp_DisableDebugLog.boolValue);

            EditorGUILayout.Space(10);
            EditorGUILayout.LabelField("DebugWindow", EditorStyles.boldLabel);
            sp_DrawDebugWindow.boolValue = EditorGUILayout.ToggleLeft("EnableDebugWindow", sp_DrawDebugWindow.boolValue);

            //EditorGUILayout.Space(10);
            //EditorGUILayout.LabelField("ResourceLoadConfig", EditorStyles.boldLabel);
            //resourceLoaderIndex = EditorGUILayout.Popup("ResourceLoaders", resourceLoaderIndex, resourceLoaders);

            //if (resourceLoaderIndex != sp_ResourceLoaderIndex.intValue)
            //{
            //    sp_ResourceLoaderIndex.intValue = resourceLoaderIndex;
            //}
            //var loaderLength = resourceLoaders.Length;
            //if (loaderLength > 0 && resourceLoaderIndex < loaderLength)
            //{
            //    sp_ResourceLoaderName.stringValue = resourceLoaders[resourceLoaderIndex];
            //}
            targetObject.ApplyModifiedProperties();
        }
        void OnEnable()
        {
            kryptonLauncher = target as KryptonLauncher;
            targetObject = new SerializedObject(kryptonLauncher);

            //var srcLoaders = Utility.Assembly.GetDerivedTypeNames<IResouceLoader>();
            //resourceLoaders = new string[srcLoaders.Length + 1];
            //resourceLoaders[0] = "<NONE>";
            //Array.Copy(srcLoaders, 0, resourceLoaders, 1, srcLoaders.Length);

            //sp_ResourceLoaderName = targetObject.FindProperty("resourceLoaderName");
            //sp_ResourceLoaderIndex = targetObject.FindProperty("resourceLoaderIndex");
            sp_DrawDebugWindow = targetObject.FindProperty("drawDebugWindow");
            sp_DisableDebugLog = targetObject.FindProperty("disableDebugLog");
            //resourceLoaderIndex = sp_ResourceLoaderIndex.intValue;
        }

    }
}
