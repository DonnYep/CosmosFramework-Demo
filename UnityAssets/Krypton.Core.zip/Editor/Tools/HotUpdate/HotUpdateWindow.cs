using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

namespace Krypton.Editor.Config
{
    public class HotUpdateWindow : EditorWindow
    {

        const string HotUpdateWindowData = "HotUpdateWindowData.json";
        Vector2 m_ScrollPos;
        [MenuItem("Window/Krypton/Tools/HotUpdate")]
        public static void OpenWindow()
        {
            var window = GetWindow<HotUpdateWindow>();
        }
        private void OnEnable()
        {
            
        }
        private void OnGUI()
        {
            m_ScrollPos = EditorGUILayout.BeginScrollView(m_ScrollPos);
            EditorGUILayout.EndScrollView();
        }
        private void OnDisable()
        {
            
        }
    }
}
