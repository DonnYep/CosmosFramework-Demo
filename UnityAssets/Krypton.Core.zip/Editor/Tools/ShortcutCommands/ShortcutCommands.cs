using UnityEditor;
using UnityEngine;
namespace Krypton.Editor
{
    /// <summary>
    /// 快捷键命令
    /// </summary>
    public class ShortcutCommands
    {
        [MenuItem("Window/Krypton/ShortcutCommands/OpenPersistentDataPath")]
        public static void OpenPersistentDataPath()
        {
            string path = Application.persistentDataPath;
            EditorUtility.RevealInFinder(path);
        }
    }
}
