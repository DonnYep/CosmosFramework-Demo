﻿using UnityEngine;
using System.Collections.Generic;
using System;

namespace Krypton
{
    public class KryptonLauncher : MonoSingleton<KryptonLauncher>
    {
        [SerializeField] bool drawDebugWindow = false;
        [SerializeField] bool disableDebugLog;
        bool isInited = false;
        Dictionary<Type, IModule> moduleTypeDict = new Dictionary<Type, IModule>();
        List<IModule> moduleList = new List<IModule>();
        void Awake()
        {
            if (instance != null)
            {
                isInited = false;
                GameObject.Destroy(this);
            }
            else
            {
                Utility.Debug.DisableDebugLog = disableDebugLog;
                instance = this;
                isInited = true;
                DontDestroyOnLoad(gameObject);
                var assemblies = Utility.Assembly.DomainAssemblies;
                foreach (var asm in assemblies)
                {
                    var modules = Utility.Assembly.GetDerivedTypeInstances<IModule>(asm);
                    for (int i = 0; i < modules.Length; i++)
                    {
                        var module = modules[i];
                        var type = module.ModuleType;
                        moduleTypeDict.Add(type, module);
                        moduleList.Add(module);
                    }
                }
                var length = moduleList.Count;
                for (int i = 0; i < length; i++)
                {
                    var module = moduleList[i];
                    module.OnInitialization();
                }
                if (drawDebugWindow)
                    gameObject.AddComponent<DebugWindow>();
            }
        }
        void Update()
        {
            var length = moduleList.Count;
            for (int i = 0; i < length; i++)
            {
                var module = moduleList[i];
                module.OnRefresh();
            }
        }
        void OnDestroy()
        {
            if (!isInited)
                return;
            var length = moduleList.Count;
            for (int i = 0; i < length; i++)
            {
                var module = moduleList[i];
                module.OnTermination();
            }
        }
    }
}