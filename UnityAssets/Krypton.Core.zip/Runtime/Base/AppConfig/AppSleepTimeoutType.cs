﻿namespace Krypton
{
    public enum AppSleepTimeoutType
    {
        NeverSleep=0,
        SystemSetting=1,
        CustomeTimeout=2
    }
}
