using UnityEngine;
namespace Krypton
{
    public class KryptonAppConfig : MonoBehaviour
    {
        [SerializeField] bool runInBackground = true;
        [SerializeField] bool multiTouchEnabled = false;
        [SerializeField] int targetFrameRate = 60;
        [SerializeField] AppSleepTimeoutType appSleepTimeoutType = AppSleepTimeoutType.NeverSleep;
        [SerializeField] int sleepTimeout;
        [SerializeField] public ScreenOrientation screenOrientation = ScreenOrientation.Portrait;
        [SerializeField] bool portrait = true;
        [SerializeField] bool portraitUpsideDown = false;
        [SerializeField] bool landscapeRight = false;
        [SerializeField] bool landscapeLeft = false;
        void Awake()
        {
            //多点触控
            Input.multiTouchEnabled = multiTouchEnabled;
            //锁定帧率
            Application.targetFrameRate = targetFrameRate;
            Application.runInBackground = runInBackground;
            //熄屏设置
            switch (appSleepTimeoutType)
            {
                case AppSleepTimeoutType.NeverSleep:
                    Screen.sleepTimeout = SleepTimeout.NeverSleep;
                    break;
                case AppSleepTimeoutType.SystemSetting:
                    Screen.sleepTimeout = SleepTimeout.SystemSetting;
                    break;
                case AppSleepTimeoutType.CustomeTimeout:
                    Screen.sleepTimeout = sleepTimeout;
                    break;
            }
            //画面旋转设置
            Screen.orientation = screenOrientation;
            if (Screen.orientation == ScreenOrientation.AutoRotation)
            {
                Screen.autorotateToLandscapeRight = landscapeRight;
                Screen.autorotateToLandscapeLeft = landscapeLeft;
                Screen.autorotateToPortrait = portrait;
                Screen.autorotateToPortraitUpsideDown = portraitUpsideDown;
            }
        }
    }
}
