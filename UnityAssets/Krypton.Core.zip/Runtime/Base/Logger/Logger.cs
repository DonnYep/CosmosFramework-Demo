﻿using UnityEngine;
using System.IO;
using System;
using System.Text;

namespace Krypton
{
    public enum LogFilePathType
    {
        UnityEditorPath,
        PersistentPath,
        CustomePath
    }
    public class Logger : MonoBehaviour
    {
        [SerializeField] LogFilePathType logFilePathType;
        [SerializeField] string path = "GameLog.log";
        string filePath;
        UTF8Encoding utf8Encoding = new UTF8Encoding(false);
        readonly string[] separator = new string[] { "</color></b>" };
        LoggerHelper loggerHelper;
        void Awake()
        {
            switch (logFilePathType)
            {
                case LogFilePathType.UnityEditorPath:
#if UNITY_EDITOR
                    var dir = new DirectoryInfo(Application.dataPath);
                    filePath = Path.Combine(dir.Parent.FullName, "Logs", path);
#endif
                    break;
                case LogFilePathType.PersistentPath:
                    filePath = Path.Combine(Application.persistentDataPath, "Logs", path);
                    break;
            }
            if (string.IsNullOrWhiteSpace(filePath))
                return;
            var folderPath = Path.GetDirectoryName(filePath);
#if UNITY_EDITOR
            Debug.Log($"log path: {filePath}");
#endif
            if (!Directory.Exists(folderPath))
                Directory.CreateDirectory(folderPath);
            Application.logMessageReceived += OnLogMessageReceived;
        }
        void OnDestroy()
        {
            if (string.IsNullOrWhiteSpace(filePath))
                return;
            Application.logMessageReceived -= OnLogMessageReceived;
        }
        void OnLogMessageReceived(string condition, string stackTrace, LogType type)
        {
            string message = string.Empty;
            try
            {
                string[] stringArray = null;
                stringArray = condition.Split(separator, StringSplitOptions.None);
                if (stringArray.Length > 1)
                {
                    message = stringArray[1];
                }
            }
            catch { }
            message = string.IsNullOrEmpty(message) ? condition : message;
            var context = string.Format("{0} Unity{1} [ - ] {2} \nstackTrace At:\n{3}", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), type, message, stackTrace);
            using (StreamWriter writer = new StreamWriter(filePath, true, utf8Encoding))
            {
                writer.WriteLine(context);
                writer.Flush();
            }
        }
    }
}