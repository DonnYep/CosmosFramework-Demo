﻿using UnityEngine;

namespace Krypton
{
    public interface LoggerHelper
    {
        void OnError(string condition, string stackTrace, LogType type);
        void OnAssert(string condition, string stackTrace, LogType type);
        void OnWarning(string condition, string stackTrace, LogType type);
        void OnLog(string condition, string stackTrace, LogType type);
        void OnException(string condition, string stackTrace, LogType type);
    }
}
