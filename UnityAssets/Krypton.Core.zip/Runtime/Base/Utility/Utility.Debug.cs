﻿using Object = UnityEngine.Object;
namespace Krypton
{
    public enum DebugColor : byte
    {
        black,
        blue,
        brown,
        cyan,
        darkblue,
        fuchsia,
        green,
        grey,
        lightblue,
        lime,
        maroon,
        navy,
        olive,
        orange,
        purple,
        red,
        silver,
        teal,
        white,
        yellow
    }
    public static partial class Utility
    {
        public static class Debug
        {
            public static bool DisableDebugLog { get; set; }
            public static void LogInfo(object msg, DebugColor logColor = DebugColor.cyan)
            {
                if (DisableDebugLog)
                    return;
                UnityEngine.Debug.Log($"<b><color={logColor}>{"[LOG]-->>"}</color></b>{msg}");
            }
            public static void LogInfo(object msg, Object context, DebugColor logColor = DebugColor.cyan)
            {
                if (DisableDebugLog)
                    return;
                UnityEngine.Debug.Log($"<b><color={logColor}>{"[LOG]-->>"}</color></b>{msg}", context);
            }
            public static void LogWarning(object msg)
            {
                if (DisableDebugLog)
                    return;
                UnityEngine.Debug.LogWarning($"<b><color={DebugColor.orange}>{"[WARNING]-->>" }</color></b>{msg}");
            }
            public static void LogWarning(object msg, Object context)
            {
                if (DisableDebugLog)
                    return;
                UnityEngine.Debug.LogWarning($"<b><color={DebugColor.orange}>{"[WARNING]-->>" }</color></b>{msg}", context);
            }
            public static void LogError(object msg)
            {
                if (DisableDebugLog)
                    return;
                UnityEngine.Debug.LogError($"<b><color={DebugColor.red}>{"[ERROR]-->>"} </color></b>{msg}");
            }
            public static void LogError(object msg, Object context)
            {
                if (DisableDebugLog)
                    return;
                UnityEngine.Debug.LogError($"<b><color={DebugColor.red}>{"[ERROR]-->>"}</color></b>{msg}", context);
            }
        }
    }
}