﻿using System;
using System.Text;

namespace Krypton
{
    public static partial class Utility
    {
        public static class Converter
        {
            /// <summary>
            /// 解码base64；
            /// </summary>
            /// <param name="context">需要解码的内容</param>
            /// <returns>解码后的内容</returns>
            public static string DecodeFromBase64(string context)
            {
                return Encoding.UTF8.GetString(Convert.FromBase64String(context));
            }
            /// <summary>
            /// 编码base64
            /// </summary>
            /// <param name="context">需要编码的内容</param>
            /// <returns>编码后的内容</returns>
            public static string EncodeToBase64(string context)
            {
                return Convert.ToBase64String(Encoding.UTF8.GetBytes(context));
            }
            /// <summary>
            /// 转换byte长度到对应单位
            /// </summary>
            /// <param name="bytes">byte长度</param>
            /// <param name="decimalPlaces">保留的小数长度</param>
            /// <returns>格式化后的单位</returns>
            public static string FormatBytes(double bytes, int decimalPlaces = 2)
            {
                string[] sizeUnits = { "Byte", "KB", "MB", "GB", "TB", "PB", "EB" };
                double size = bytes;
                int unitIndex = 0;
                while (size >= 1024 && unitIndex < sizeUnits.Length - 1)
                {
                    size /= 1024;
                    unitIndex++;
                }
                string formatString = "0." + new string('0', decimalPlaces);

                return $"{Math.Round(size, decimalPlaces).ToString(formatString)}{sizeUnits[unitIndex]}";
            }
            public static string Convert2String(byte[] bytes)
            {
                return Encoding.UTF8.GetString(bytes);
            }
        }
    }
}