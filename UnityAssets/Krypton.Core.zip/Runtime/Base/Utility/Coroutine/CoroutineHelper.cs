﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Krypton
{
    public enum FrameType
    {
        Update,
        FixedUpdate,
    }
    [DisallowMultipleComponent]
    public class CoroutineHelper : MonoBehaviour
    {
        class FrameTask : IEquatable<FrameTask>
        {
            public long TaskId;
            public long CurrentFrame;
            public long TargetFrame;
            public Action Action;
            public bool Equals(FrameTask other)
            {
                return other.TaskId == this.TaskId;
            }
            public void Release()
            {
                TaskId = -1;
                CurrentFrame = 0;
                TargetFrame = 0;
                Action = null;
            }
        }
        class DelayTask : IEquatable<DelayTask>
        {
            public long taskId;
            public float delay;
            public float currentTime;
            public Action action;

            public bool Equals(DelayTask other)
            {
                return other.taskId == this.taskId;
            }
        }
        class ConditionTask : IEquatable<ConditionTask>
        {
            public long taskId;
            public float timeout;
            public float currentTime;
            public Func<bool> condition;
            public Action action;

            public bool Equals(ConditionTask other)
            {
                return other.taskId == this.taskId;
            }
        }
        static long taskIndex = 0;

        static long updateFrame = 0;
        static long fixedUpdateFrame = 0;

        readonly Dictionary<long, FrameTask> updateFrameTaskDict = new Dictionary<long, FrameTask>();
        readonly List<FrameTask> updateFrameTaskList = new List<FrameTask>();
        readonly List<FrameTask> removalUpdateFrameTaskList = new List<FrameTask>();

        readonly Dictionary<long, FrameTask> fixedupdateFrameTaskDict = new Dictionary<long, FrameTask>();
        readonly List<FrameTask> fixedupdateFrameTaskList = new List<FrameTask>();
        readonly List<FrameTask> removalFixedUpdateFrameTaskList = new List<FrameTask>();

        readonly Dictionary<long, FrameType> taskIdFrameTypeDict = new Dictionary<long, FrameType>();

        List<IEnumerator> routineList = new List<IEnumerator>();
        readonly Dictionary<long, DelayTask> delayTaskDict = new Dictionary<long, DelayTask>();
        readonly List<DelayTask> delayTaskList = new List<DelayTask>();
        readonly List<DelayTask> delayRemovalTaskList = new List<DelayTask>();

        readonly Dictionary<long, ConditionTask> conditionTaskDict = new Dictionary<long, ConditionTask>();
        readonly List<ConditionTask> conditionTaskList = new List<ConditionTask>();
        readonly List<ConditionTask> conditionRemovalTaskList = new List<ConditionTask>();
        /// <summary>
        /// 添加等待帧任务
        /// </summary>
        /// <param name="frameType">帧类型</param>
        /// <param name="action">触发的事件</param>
        /// <param name="frameCount">帧数</param>
        /// <returns>任务Id</returns>
        public long AddFrameTask(FrameType frameType, Action action, long frameCount = 1)
        {
            if (frameCount < 0)
                frameCount = 1;
            var taskId = taskIndex++;
            var frameTask =new FrameTask();
            frameTask.TaskId = taskId;
            frameTask.Action = action;
            switch (frameType)
            {
                case FrameType.Update:
                    {
                        frameTask.CurrentFrame = updateFrame;
                        frameTask.TargetFrame = updateFrame + frameCount;
                        updateFrameTaskList.Add(frameTask);
                        updateFrameTaskDict.Add(frameTask.TaskId, frameTask);
                    }
                    break;
                case FrameType.FixedUpdate:
                    {
                        frameTask.CurrentFrame = fixedUpdateFrame;
                        frameTask.TargetFrame = fixedUpdateFrame + frameCount;
                        fixedupdateFrameTaskList.Add(frameTask);
                        fixedupdateFrameTaskDict.Add(frameTask.TaskId, frameTask);
                    }
                    break;
            }
            taskIdFrameTypeDict.Add(frameTask.TaskId, frameType);
            return frameTask.TaskId;
        }
        /// <summary>
        /// 移除等待帧数任务，能够通过taslId识别任务类型。
        /// </summary>
        /// <param name="taskId">任务Id</param>
        public void RemoveFrameTask(long taskId)
        {
            var has = taskIdFrameTypeDict.TryRemove(taskId, out var type);
            if (has)
            {
                switch (type)
                {
                    case FrameType.Update:
                        {
                            updateFrameTaskDict.TryRemove(taskId, out var frameTask);
                            updateFrameTaskList.Remove(frameTask);
                        }
                        break;
                    case FrameType.FixedUpdate:
                        {
                            fixedupdateFrameTaskDict.TryRemove(taskId, out var frameTask);
                            fixedupdateFrameTaskList.Remove(frameTask);
                        }
                        break;
                }
            }
        }
        public long AddConditionTask(Func<bool> condition, Action action, float timeout)
        {
            var taskId = taskIndex++;
            var conditionTask = new ConditionTask()
            {
                taskId = taskId,
                condition = condition,
                action = action,
                timeout = timeout,
                currentTime = 0,
            };
            conditionTaskList.Add(conditionTask);
            conditionTaskDict.Add(taskId, conditionTask);
            return taskId;
        }
        public long AddDelayTask(float delay, Action action)
        {
            var taskId = taskIndex++;
            var delayTask = new DelayTask()
            {
                taskId = taskId,
                currentTime = 0,
                delay = delay,
                action = action,
            };
            delayTaskList.Add(delayTask);
            delayTaskDict.Add(taskId, delayTask);
            return taskId;
        }
        public void RemoveConditionTask(long taskId)
        {
            if (conditionTaskDict.TryRemove(taskId, out var delayTask))
            {
                conditionTaskList.Remove(delayTask);
            }
        }
        public void RemoveDelayTask(long taskId)
        {
            if (delayTaskDict.TryRemove(taskId, out var delayTask))
            {
                delayTaskList.Remove(delayTask);
            }
        }
        public void AddRoutine(IEnumerator routine)
        {
            routineList.Add(routine);
        }
        public Coroutine PredicateCoroutine(Func<bool> handler, Action callBack)
        {
            return StartCoroutine(EnumPredicateCoroutine(handler, callBack));
        }
        /// <summary>
        /// 嵌套协程；
        /// </summary>
        /// <param name="predicateHandler">条件函数</param>
        /// <param name="nestHandler">条件成功后执行的嵌套协程</param>
        /// <returnsCoroutine></returns>
        public Coroutine PredicateNestCoroutine(Func<bool> predicateHandler, Action nestHandler)
        {
            return StartCoroutine(EnumPredicateNestCoroutine(predicateHandler, nestHandler));
        }
        public Coroutine DelayCoroutine(float delay, Action callBack)
        {
            return StartCoroutine(EnumDelay(delay, callBack));
        }
        public Coroutine StartCoroutine(Action handler)
        {
            return StartCoroutine(EnumCoroutine(handler));
        }
        public Coroutine StartCoroutine(Action handler, Action callback)
        {
            return StartCoroutine(EnumCoroutine(handler, callback));
        }
        /// <summary>
        /// 嵌套协程
        /// </summary>
        /// <param name="routine">执行条件</param>
        /// <param name="callBack">执行条件结束后自动执行回调函数</param>
        /// <returns>Coroutine</returns>
        public Coroutine StartCoroutine(Coroutine routine, Action callBack)
        {
            return StartCoroutine(EnumCoroutine(routine, callBack));
        }
        void Update()
        {
            while (routineList.Count > 0)
            {
                var r = routineList[0];
                routineList.RemoveAt(0);
                StartCoroutine(r);
            }
            RefreshDelayTask();
            RefreshConditionTask();
            RefreshUpdateFrameTask();
        }
        private void FixedUpdate()
        {
            RefreshFixedUpdateFrameTask();
        }
        IEnumerator EnumDelay(float delay, Action callBack)
        {
            yield return new WaitForSeconds(delay);
            callBack?.Invoke();
        }
        IEnumerator EnumCoroutine(Coroutine routine, Action callBack)
        {
            yield return routine;
            callBack?.Invoke();
        }
        IEnumerator EnumCoroutine(Action handler)
        {
            handler?.Invoke();
            yield return null;
        }
        IEnumerator EnumCoroutine(Action handler, Action callack)
        {
            yield return StartCoroutine(handler);
            callack?.Invoke();
        }
        IEnumerator EnumPredicateCoroutine(Func<bool> handler, Action callBack)
        {
            yield return new WaitUntil(handler);
            callBack();
        }
        /// <summary>
        /// 嵌套协程执行体；
        /// </summary>
        /// <param name="predicateHandler">条件函数</param>
        /// <param name="nestHandler">条件成功后执行的嵌套协程</param>
        IEnumerator EnumPredicateNestCoroutine(Func<bool> predicateHandler, Action nestHandler)
        {
            yield return new WaitUntil(predicateHandler);
            yield return StartCoroutine(EnumCoroutine(nestHandler));
        }
        void RefreshDelayTask()
        {
            var taskCount = delayTaskList.Count;
            delayRemovalTaskList.Clear();
            for (int i = 0; i < taskCount; i++)
            {
                var task = delayTaskList[i];
                task.currentTime += Time.deltaTime;
                if (task.currentTime >= task.delay)
                {
                    try
                    {
                        task.action?.Invoke();
                    }
                    catch (Exception e)
                    {
                        Utility.Debug.LogError(e);
                    }
                    delayRemovalTaskList.Add(task);
                }
            }
            var removeCount = delayRemovalTaskList.Count;
            for (int i = 0; i < removeCount; i++)
            {
                var removeTask = delayRemovalTaskList[i];
                delayTaskList.Remove(removeTask);
                delayTaskDict.Remove(removeTask.taskId);
            }
        }
        void RefreshConditionTask()
        {
            var taskCount = conditionTaskList.Count;
            conditionRemovalTaskList.Clear();
            for (int i = 0; i < taskCount; i++)
            {
                var task = conditionTaskList[i];
                task.currentTime += Time.deltaTime;
                if (task.currentTime >= task.timeout)
                {
                    conditionRemovalTaskList.Add(task);
                    continue;
                }
                bool triggered = false;
                if (task.condition == null)
                {
                    triggered = true;
                }
                else
                {
                    try
                    {
                        triggered = task.condition.Invoke();
                    }
                    catch (Exception e)
                    {
                        Utility.Debug.LogError(e);
                        triggered = true;
                    }
                }
                if (triggered)
                {
                    try
                    {
                        task.action?.Invoke();
                    }
                    catch (Exception e)
                    {
                        Utility.Debug.LogError(e);
                    }
                    conditionRemovalTaskList.Add(task);
                }
            }
            var removeCount = conditionRemovalTaskList.Count;
            for (int i = 0; i < removeCount; i++)
            {
                var removeTask = conditionRemovalTaskList[i];
                conditionTaskList.Remove(removeTask);
                conditionTaskDict.Remove(removeTask.taskId);
            }
        }
        void RefreshUpdateFrameTask()
        {
            updateFrame++;
            removalUpdateFrameTaskList.Clear();
            var taskArray = updateFrameTaskList;
            var taskCount = taskArray.Count;
            for (int i = 0; i < taskCount; i++)
            {
                var task = taskArray[i];
                task.CurrentFrame++;
                if (task.CurrentFrame >= task.TargetFrame)
                {
                    try
                    {
                        task.Action?.Invoke();
                    }
                    catch (Exception e)
                    {
                        Utility.Debug.LogError(e);
                    }
                    removalUpdateFrameTaskList.Add(task);
                }
            }
            var removeCount = removalUpdateFrameTaskList.Count;
            for (int i = 0; i < removeCount; i++)
            {
                var removeTask = removalUpdateFrameTaskList[i];
                RemoveFrameTask(removeTask.TaskId);
            }
        }
        void RefreshFixedUpdateFrameTask()
        {
            fixedUpdateFrame++;
            removalFixedUpdateFrameTaskList.Clear();
            var taskArray = fixedupdateFrameTaskList;
            var taskCount = taskArray.Count;
            for (int i = 0; i < taskCount; i++)
            {
                var task = taskArray[i];
                task.CurrentFrame++;
                if (task.CurrentFrame >= task.TargetFrame)
                {
                    try
                    {
                        task.Action?.Invoke();
                    }
                    catch (Exception e)
                    {
                        Utility.Debug.LogError(e);
                    }
                    removalFixedUpdateFrameTaskList.Add(task);
                }
            }
            var removeCount = removalFixedUpdateFrameTaskList.Count;
            for (int i = 0; i < removeCount; i++)
            {
                var removeTask = removalFixedUpdateFrameTaskList[i];
                RemoveFrameTask(removeTask.TaskId);
            }
        }
    }
}
