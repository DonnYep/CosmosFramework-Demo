﻿namespace Krypton
{
    public static partial class Utility { }
}