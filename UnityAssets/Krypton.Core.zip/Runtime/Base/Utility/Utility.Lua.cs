﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;

namespace Krypton
{
    public static partial class Utility
    {
        public static class Lua
        {
            delegate Type MakeGenericDelegateType(params Type[] paramTypes);
            /// <summary>
            /// 生成Array；
            /// </summary>
            /// <param name="elementType">元素类型</param>
            /// <param name="itemCount">长度</param>
            /// <returns>生成的Array</returns>
            public static Array CreateArrayInstance(Type elementType, int itemCount)
            {
                return Array.CreateInstance(elementType, itemCount);
            }
            /// <summary>
            /// 反射生成IList；
            /// </summary>
            /// <param name="itemType">类型</param>
            /// <returns>IList对象</returns>
            public static IList CreateListInstance(Type itemType)
            {
                return (IList)Activator.CreateInstance(MakeGenericListType(itemType));
            }
            /// <summary>
            /// 反射生成IDictionary；
            /// </summary>
            /// <param name="keyType">Key类型</param>
            /// <param name="valueType">Value类型</param>
            /// <returns>IDictionary对象</returns>
            public static IDictionary CreateDictionaryInstance(Type keyType, Type valueType)
            {
                return (IDictionary)Activator.CreateInstance(MakeGenericDictionaryType(keyType, valueType));
            }
            /// <summary>
            /// 创建Action类型委托；
            /// </summary>
            /// <param name="type">类型</param>
            /// <param name="methodName">方法名</param>
            /// <param name="paramTypes">参数类型</param>
            /// <returns>委托</returns>
            public static Delegate CreateActionDelegate(Type type, string methodName, params Type[] paramTypes)
            {
                return InnerCreateDelegate(MakeGenericActionType, null, type, methodName, paramTypes);
            }
            /// <summary>
            /// 创建Action类型委托；
            /// </summary>
            /// <param name="target">目标对象</param>
            /// <param name="methodName">方法名</param>
            /// <param name="paramTypes">参数类型</param>
            /// <returns>委托</returns>
            public static Delegate CreateActionDelegate(object target, string methodName, params Type[] paramTypes)
            {
                return InnerCreateDelegate(MakeGenericActionType, target, null, methodName, paramTypes);
            }
            /// <summary>
            /// 构建泛型List类型；
            /// </summary>
            /// <param name="itemType">元素类型</param>
            /// <returns>List Type</returns>
            public static Type MakeGenericListType(Type itemType)
            {
                return typeof(List<>).MakeGenericType(itemType);
            }
            /// <summary>
            /// 构建Dictionary类型；
            /// </summary>
            /// <param name="keyType">Key类型</param>
            /// <param name="valueType">Value类型</param>
            /// <returns>Dictionary Type</returns>
            public static Type MakeGenericDictionaryType(Type keyType, Type valueType)
            {
                return typeof(Dictionary<,>).MakeGenericType(new Type[] { keyType, valueType });
            }
            /// <summary>
            /// 构建Action类型；
            /// </summary>
            /// <param name="paramTypes">参数类型</param>
            /// <returns>Action Type</returns>
            public static Type MakeGenericActionType(params Type[] paramTypes)
            {
                if (paramTypes == null || paramTypes.Length == 0)
                {
                    return typeof(Action);
                }
                else if (paramTypes.Length == 1)
                {
                    return typeof(Action<>).MakeGenericType(paramTypes);
                }
                else if (paramTypes.Length == 2)
                {
                    return typeof(Action<,>).MakeGenericType(paramTypes);
                }
                else
                {
                    return typeof(Action<,,,>).MakeGenericType(paramTypes);
                }
            }
            // 说明：创建委托
            // 注意：重载函数的定义顺序很重要：从更具体类型（Type）到不具体类型（object）,
            // xlua生成导出代码和lua侧函数调用匹配时都是从上到下的，如果不具体类型（object）写在上面，
            // 则永远也匹配不到更具体类型（Type）的重载函数，很坑爹
            static Delegate InnerCreateDelegate(MakeGenericDelegateType del, object target, Type type, string methodName, params Type[] paramTypes)
            {
                if (target != null)
                {
                    type = target.GetType();
                }
                BindingFlags bindingFlags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static;
                MethodInfo methodInfo = (paramTypes == null || paramTypes.Length == 0)
                    ? type.GetMethod(methodName, bindingFlags)
                    : type.GetMethod(methodName, bindingFlags, null, paramTypes, null);
                Type delegateType = del(paramTypes);
                return Delegate.CreateDelegate(delegateType, target, methodInfo);
            }
        }
    }
}
