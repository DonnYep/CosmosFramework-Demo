﻿namespace Krypton
{
    public interface  IReference 
    {
        /// <summary>
        /// 清空引用
        /// </summary>
        void Release();
    }
}