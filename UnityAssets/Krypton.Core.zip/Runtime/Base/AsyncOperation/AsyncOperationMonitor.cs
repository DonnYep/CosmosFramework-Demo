﻿using System.Collections.Generic;

namespace Krypton.AsyncOperation
{
    internal class AsyncOperationMonitor
    {
        static readonly List<IAsyncOperation> operationList = new List<IAsyncOperation>(512);
        static readonly List<IAsyncOperation> newList = new List<IAsyncOperation>(512);

        public static void Update()
        {
            // 添加新增的异步操作
            if (newList.Count > 0)
            {
                bool sorting = false;
                foreach (var operation in newList)
                {
                    if (operation.Priority > 0)
                    {
                        sorting = true;
                        break;
                    }
                }

                operationList.AddRange(newList);
                newList.Clear();

                // 重新排序优先级
                if (sorting)
                    operationList.Sort();
            }
            // 更新进行中的异步操作
            for (int i = 0; i < operationList.Count; i++)
            {
                var operation = operationList[i];
                if (operation.IsFinish)
                    continue;

                if (operation.IsDone == false)
                    operation.OnUpdate();

                if (operation.IsDone)
                    operation.SetFinish();
            }
            // 移除已经完成的异步操作
            for (int i = operationList.Count - 1; i >= 0; i--)
            {
                var operation = operationList[i];
                if (operation.IsFinish)
                    operationList.RemoveAt(i);
            }
        }

        /// <summary>
        /// 销毁异步操作系统
        /// </summary>
        public static void DestroyAll()
        {
            operationList.Clear();
            newList.Clear();
        }
        public static void StartOperation(IAsyncOperation operation)
        {
            operationList.Add(operation);
            operation.SetStart();
        }
        public static void StopOperation(IAsyncOperation operation)
        {
            operationList.Remove(operation);
            operation.SetAbort();
        }
    }
}
