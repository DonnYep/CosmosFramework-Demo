﻿using Krypton.AsyncOperation;
using System;
using System.Collections;
using System.Threading.Tasks;

namespace Krypton
{
    public struct AsyncOperationHandle<T> : IEnumerator, IEquatable<AsyncOperationHandle<T>>
    {
        IAsyncOperation operation;
        public Task<T> Task
        {
            get
            {
                var op = (AsyncOperationBase<T>)operation;
                return op.Task;
            }
        }
        public IAsyncOperation Operation
        {
            get { return operation; }
        }
        public Type ResultType
        {
            get { return typeof(T); }
        }
        public T Result
        {
            get { return (T)operation.GetResult(); }
        }
        public bool IsDone
        {
            get { return operation.IsDone; }
        }
        public float Progress
        {
            get { return operation.Progress; }
        }
        object IEnumerator.Current { get { return null; } }
        Action<AsyncOperationHandle<T>> completed;
        public event Action<AsyncOperationHandle<T>> Completed
        {
            add
            {
                if (operation.IsDone)
                    value?.Invoke(this);
                else
                    completed += value;
            }
            remove
            {
                completed -= value;
            }
        }
        public AsyncOperationHandle(IAsyncOperation operation)
        {
            completed = null;
            this.operation = operation;
            operation.OnCompleted += OnOperationCompleted;
            AsyncOperationMonitor.StartOperation(operation);
        }
        public T WaitForCompletion()
        {
            operation.WaitForCompletion();
            return (T)operation.GetResult();
        }
        public void Abort()
        {
            AsyncOperationMonitor.StopOperation(operation);
        }
        #region 实现 IEnumerator 接口
        public bool Equals(AsyncOperationHandle<T> other)
        {
            return operation == other.operation;
        }
        bool IEnumerator.MoveNext()
        {
            return !operation.IsDone;
        }
        void IEnumerator.Reset() { }
        #endregion
        void OnOperationCompleted(IAsyncOperation operation)
        {
            completed?.Invoke(this);
        }
        static public implicit operator AsyncOperationHandle(AsyncOperationHandle<T> operationHandle)
        {
            return new AsyncOperationHandle(operationHandle.operation);
        }
    }
    public struct AsyncOperationHandle : IEnumerator, IEquatable<AsyncOperationHandle>
    {
        IAsyncOperation operation;
        public Task<UnityEngine.Object> Task
        {
            get { return ((AsyncOperationBase<UnityEngine.Object>)operation).Task; }
        }
        public Type ResultType
        {
            get { return operation.ResultType; }
        }
        public IAsyncOperation Operation
        {
            get { return operation; }
        }
        public UnityEngine.Object Result
        {
            get { return (UnityEngine.Object)operation.GetResult(); }
        }
        public bool IsDone
        {
            get { return operation.IsDone; }
        }
        public float Progress
        {
            get { return operation.Progress; }
        }
        object IEnumerator.Current { get { return null; } }
        Action<AsyncOperationHandle> completed;
        public event Action<AsyncOperationHandle> Completed
        {
            add
            {
                if (operation.IsDone)
                    value?.Invoke(this);
                else
                    completed += value;
            }
            remove
            {
                completed -= value;
            }
        }
        public AsyncOperationHandle(IAsyncOperation operation)
        {
            completed = null;
            this.operation = operation;
            operation.OnCompleted += OnOperationCompleted;
            AsyncOperationMonitor.StartOperation(operation);
        }
        //public void WaitForCompletion()
        //{
        //    operation.WaitForCompletion();
        //}
        public void Abort()
        {
            AsyncOperationMonitor.StopOperation(operation);
        }
        #region 实现 IEnumerator 接口
        public bool Equals(AsyncOperationHandle other)
        {
            return operation == other.operation;
        }
        bool IEnumerator.MoveNext()
        {
            return !operation.IsDone;
        }
        void IEnumerator.Reset() { }
        #endregion
        void OnOperationCompleted(IAsyncOperation operation)
        {
            completed?.Invoke(this);
        }
        public AsyncOperationHandle<T> Convert<T>()
        {
            return new AsyncOperationHandle<T>(operation);
        }
    }
}
