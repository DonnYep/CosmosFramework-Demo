﻿using System.Collections;
using System;
using System.Threading.Tasks;
using Krypton.AsyncOperation;
namespace Krypton
{
    /// <summary>
    /// 生命周期顺序：OnStart > OnUpdate > OnAbort > OnFinish
    /// </summary>
    public abstract class AsyncOperationBase<T> : IAsyncOperation, IEnumerator, IComparable<AsyncOperationBase<T>>
    {
        /// <summary>
        ///IEnumerator.Current
        /// </summary>
        public object Current { get { return null; } }
        private TaskCompletionSource<T> tcs = new TaskCompletionSource<T>();
        public Type ResultType
        {
            get { return typeof(T); }
        }
        public AsyncOperationStatus Status { get; protected set; } = AsyncOperationStatus.None;
        public uint Priority { set; get; }
        public bool IsFinish { get; protected set; }
        public float Progress { get; protected set; }
        public string Error { get; protected set; }
        public Task<T> Task
        {
            get { return tcs.Task; }
        }
        public T Result { get; protected set; }
        public bool IsDone
        {
            get
            {
                return Status == AsyncOperationStatus.Failed
                    || Status == AsyncOperationStatus.Succeeded;
            }
        }
        /// <summary>
        /// 是否已经完成
        /// </summary>
        protected Action<IAsyncOperation> onCompleted;
        public event Action<IAsyncOperation> OnCompleted
        {
            add
            {
                if (IsDone)
                    value.Invoke(this);
                else
                    onCompleted += value;
            }
            remove { onCompleted -= value; }
        }
        public virtual void OnUpdate() { }
        public virtual void SetStart()
        {
            Status = AsyncOperationStatus.Processing;
            Progress = 0;
            IsFinish = false;
            OnStart();
        }
        public virtual void SetFinish()
        {
            IsFinish = true;
            Progress = 1f;
            tcs.SetResult(Result);
            onCompleted?.Invoke(this);
            OnFinish();
        }
        public virtual void SetAbort()
        {
            if (!IsDone)
            {
                Status = AsyncOperationStatus.Failed;
                Error = "user abort";
                OnAbort();
                OnFinish();
            }
        }
        public virtual void WaitForCompletion()
        {
            while (!IsDone)
            {
                System.Threading.Thread.Sleep(10);
                OnUpdate();
            }
        }
        public object GetResult()
        {
            return Result;
        }
        /// <summary>
        /// IEnumerator.MoveNext
        /// </summary>
        public bool MoveNext()
        {
            return !IsDone;
        }
        /// <summary>
        /// IEnumerator.Reset
        /// </summary>
        public void Reset() { }
        /// <summary>
        /// IComparable.CompareTo
        /// </summary>
        public virtual int CompareTo(AsyncOperationBase<T> other)
        {
            return other.Priority.CompareTo(this.Priority);
        }
        protected abstract void OnStart();
        protected virtual void OnAbort() { }
        protected virtual void OnFinish() { }
        internal void InternalStart()
        {
            AsyncOperationMonitor.StartOperation(this);
        }
        internal void InternalStop()
        {
            AsyncOperationMonitor.StopOperation(this);
        }
    }
}
