﻿namespace Krypton.AsyncOperation
{
    public enum AsyncOperationStatus : byte
    {
        None,
        Processing,
        Succeeded,
        Failed
    }
}
