﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Krypton.AsyncOperation
{
    public interface IAsyncOperation
    {
        event Action<IAsyncOperation> OnCompleted;
        AsyncOperationStatus Status { get; }
        uint Priority { set; get; }
        bool IsFinish { get; }
        bool IsDone { get; }
        Type ResultType { get; }
        float Progress { get; }
        string Error { get; }
        object GetResult();
        void SetStart();
        void SetFinish();
        void SetAbort();
        void OnUpdate();
        void WaitForCompletion();
    }
}
