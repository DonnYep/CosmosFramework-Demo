using UnityEngine;
using System.Linq;
using System.Collections.Generic;
namespace Krypton
{
    [DisallowMultipleComponent]
    public class DebugWindow : MonoBehaviour
    {
        /// <summary>
        /// debug窗口刷新数据周期，单位为秒；
        /// </summary>
        float wndDataRefreshInterval = 1f;
        float currentTime = 0;

        Rect windowRect;
        Rect dragRect = new Rect(0f, 0f, float.MaxValue, 25f);

        float windowScale;
        float tempWindowScale;
        /// <summary>
        /// 被选择的窗口
        /// </summary>
        int selectedWndIndex = 0;
        /// <summary>
        /// 被选择的Tab
        /// </summary>
        int selectedTabIndex = 0;
        string[] debugWndNames;
        Dictionary<string, DebugWindowBase> debugWndDict;

        float rectWidth;
        float rectHeight;
        string[] tabNames = new string[] { "模块", "设置" };
        bool wndMinimize = false;
        void Awake()
        {
            InitWindow();
        }
        void Start()
        {
            var debugWnds = Utility.Assembly.GetDerivedTypeInstances(typeof(DebugWindowBase), this.GetType().Assembly);
            debugWndNames = debugWnds.Select(wnd => wnd.GetType().Name).ToArray();
            debugWndDict = debugWnds.ToDictionary(wnd => wnd.GetType().Name, wnd => (wnd as DebugWindowBase));
        }
        void Update()
        {
            currentTime += Time.deltaTime;
            if (currentTime > wndDataRefreshInterval)
            {
                currentTime = 0;
                foreach (var wnd in debugWndDict.Values)
                {
                    wnd.OnRefreshData();
                }
            }
        }
        void OnGUI()
        {
            GUI.matrix = Matrix4x4.Scale(new Vector3(windowScale, windowScale, 1f));
            GUILayout.Space(16);
            wndMinimize = GUILayout.Toggle(wndMinimize, "<b>显示debugWindow</b>");
            if (GUILayout.Button("重置界面"))
            {
                InitWindow();
            }
            if (wndMinimize)
                windowRect = GUILayout.Window(0, windowRect, DrawWindow, "<b>DebugWindow</b>");
        }
        void DrawWindow(int windowId)
        {
            GUI.DragWindow(dragRect);
            GUILayout.Space(16);
            selectedTabIndex = GUILayout.SelectionGrid(selectedTabIndex, tabNames, 2);
            switch (selectedTabIndex)
            {
                case 0:
                    DrawModuleTab();
                    break;
                case 1:
                    DrawSettingTab();
                    break;
            }
        }
        void DrawSettingTab()
        {
            GUILayout.Space(16);
            GUILayout.BeginVertical("box");
            {
                GUILayout.BeginHorizontal();
                {
                    GUILayout.Label($"窗口缩放倍数:{tempWindowScale}", GUILayout.MaxWidth(128));
                    if (GUILayout.Button("缩小", GUILayout.MaxWidth(64)))
                    {
                        var wndScale = tempWindowScale - 0.1f;
                        if (wndScale < 0.1f)
                            wndScale = 0.1f;
                        tempWindowScale = wndScale;
                        windowScale = tempWindowScale;
                    }
                    tempWindowScale = GUILayout.HorizontalSlider(tempWindowScale, 0.1f, 4);
                    var scale = tempWindowScale * 10;
                    tempWindowScale = Mathf.Round(scale) / 10f;
                    if (GUILayout.Button("放大", GUILayout.MaxWidth(64)))
                    {
                        var wndScale = tempWindowScale + 0.1f;
                        if (wndScale > 8)
                            wndScale = 8;
                        tempWindowScale = wndScale;
                        windowScale = tempWindowScale;
                    }
                }
                GUILayout.EndHorizontal();

                GUILayout.Space(8);
                GUILayout.BeginHorizontal();
                {
                    GUILayout.Label($"Width {rectWidth}", GUILayout.MaxWidth(128));
                    rectWidth = GUILayout.HorizontalSlider(rectWidth, 320, 2000);
                    rectWidth = Mathf.Round(rectWidth);
                }
                GUILayout.EndHorizontal();

                GUILayout.BeginHorizontal();
                {
                    GUILayout.Label($"Height {rectHeight}", GUILayout.MaxWidth(128));
                    rectHeight = GUILayout.HorizontalSlider(rectHeight, 320, 2000);
                    rectHeight = Mathf.Round(rectHeight);
                }
                GUILayout.EndHorizontal();
                if (GUILayout.Button("更改尺寸", GUILayout.MaxWidth(128)))
                {
                    windowRect.width = rectWidth;
                    windowRect.height = rectHeight;
                }
            }
            GUILayout.EndVertical();
        }
        void DrawModuleTab()
        {
            GUILayout.BeginHorizontal();
            {
                GUILayout.Label($"数据刷新间隔{wndDataRefreshInterval}秒: ", GUILayout.MaxWidth(128));
                wndDataRefreshInterval = GUILayout.HorizontalSlider(wndDataRefreshInterval, 0.1f, 10);
                var interval = wndDataRefreshInterval * 10;
                wndDataRefreshInterval = Mathf.Round(interval) / 10f;
            }
            GUILayout.EndHorizontal();
            selectedWndIndex = GUILayout.SelectionGrid(selectedWndIndex, debugWndNames, 4);
            var wndName = debugWndNames[selectedWndIndex];
            var wnd = debugWndDict[wndName];
            wnd.OnGUI(windowRect);
        }
        void InitWindow()
        {
            var width = Screen.width * 0.3f;
            var height = Screen.height * 0.3f;
            rectWidth = width;
            rectHeight = height;
            windowRect = new Rect(10f, 32f, width, height);
            windowScale = 2f;
            tempWindowScale = windowScale;
            wndDataRefreshInterval = 1;
        }
    }
}
