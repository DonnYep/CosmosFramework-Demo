﻿using System;

namespace Krypton
{
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false, Inherited = false)]
    public class DebugWindowAttribute : Attribute { }
}
