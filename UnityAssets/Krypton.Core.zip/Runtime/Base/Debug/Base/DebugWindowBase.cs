﻿using UnityEngine;

namespace Krypton
{
    public abstract class DebugWindowBase
    {
        public virtual void OnOpen() { }
        public virtual void OnRefreshData() { }
        public virtual void OnGUI(Rect wndRect) { }
        public virtual void OnClose() { }
    }
}
