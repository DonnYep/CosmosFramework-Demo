﻿using UnityEngine;
using Krypton.Awaitable;
namespace Krypton
{
    public static class WaitForCoroutineExtensions
    {
        public static WaitForCoroutineAwaiter GetAwaiter(this Coroutine coroutine)
        {
            return new WaitForCoroutineAwaiter(coroutine);
        }
    }
}
