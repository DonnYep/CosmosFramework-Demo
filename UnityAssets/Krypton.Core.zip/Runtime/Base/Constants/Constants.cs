﻿namespace Krypton
{
    /// <summary>
    /// krypton constants
    /// </summary>
    public static class Constants
    {
        public const string NONE = "<NONE>";
    }
}
