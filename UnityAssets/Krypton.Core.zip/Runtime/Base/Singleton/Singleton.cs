﻿namespace Krypton
{
    /// <summary>
    /// 通用继承形单例
    /// </summary>
    /// <typeparam name="TDerived">继承自此单例的可构造类型</typeparam>
    public abstract class Singleton<TDerived> 
        where TDerived : class, new()
    {
        protected static TDerived instance;
        public  static TDerived Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new TDerived();
                }
                return instance;
            }
        }
    }
}
