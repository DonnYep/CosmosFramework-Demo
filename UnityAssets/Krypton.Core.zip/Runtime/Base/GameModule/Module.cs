using System;
using UnityEngine;
namespace Krypton
{
    public abstract class Module<T> : Singleton<T>, IModule
        where T : Module<T>, new()
    {
        /// <summary>
        /// 模块的泛型类型
        /// </summary>
        public Type ModuleType
        {
            get { return typeof(T); }
        }
        static GameObject instanceObject;
        /// <summary>
        /// 模块的GameObject对象实例
        /// </summary>
        public static GameObject InstanceObject
        {
            get
            {
                if (instanceObject == null)
                {
                    instanceObject = new GameObject(typeof(T).Name);
                    instanceObject.SetParent(KryptonDriver.Instance.gameObject);
                }
                return instanceObject;
            }
        }

        /// <summary>
        /// 初始化
        /// </summary>
        public virtual void OnInitialization() { }
        /// <summary>
        /// 与unity的Update同步刷新
        /// </summary>
        public virtual void OnRefresh() { }
        /// <summary>
        /// 终结
        /// </summary>
        public virtual void OnTermination() { }
    }
}
