using System;
namespace Krypton
{
    /// <summary>
    /// 模块的最高抽象
    /// </summary>
    public interface IModule
    {
        Type ModuleType { get; }
        void OnInitialization();
        void OnRefresh();
        void OnTermination();
    }
}
