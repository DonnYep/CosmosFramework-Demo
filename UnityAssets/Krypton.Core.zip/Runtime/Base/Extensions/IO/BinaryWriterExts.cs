﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Krypton
{
    public static class BinaryWriterExts
    {
        public static void WriteDouble(this BinaryWriter @this, double value)
        {
            @this.Write(value);
        }
        public static void WriteULong(this BinaryWriter @this, ulong value)
        {
            @this.Write(value);
        }
        public static void WriteUInt(this BinaryWriter @this, uint value)
        {
            @this.Write(value);
        }
        public static void WriteUShort(this BinaryWriter @this, ushort value)
        {
            @this.Write(value);
        }
        public static void WriteString(this BinaryWriter @this, string value)
        {
            @this.Write(value);
        }
        public static void WriteFloat(this BinaryWriter @this, float value)
        {
            @this.Write(value);
        }
        public static void WriteSbyte(this BinaryWriter @this, sbyte value)
        {
            @this.Write(value);
        }
        public static void WriteLong(this BinaryWriter @this, long value)
        {
            @this.Write(value);
        }
        public static void WriteInt(this BinaryWriter @this, int value)
        {
            @this.Write(value);
        }
        public static void WriteChars(this BinaryWriter @this, char[] chars)
        {
            @this.Write(chars);
        }
        public static void WriteDecimal(this BinaryWriter @this, decimal value)
        {
            @this.Write(value);
        }
        public static void WriteChar(this BinaryWriter @this, char ch)
        {
            @this.Write(ch);
        }

        public static void WriteBuffer(this BinaryWriter @this, byte[] buffer)
        {
            @this.Write(buffer);
        }
        public static void WriteByte(this BinaryWriter @this, byte value)
        {
            @this.Write(value);
        }
        public static void WriteBool(this BinaryWriter @this, bool value)
        {
            @this.Write(value);
        }
        public static void WriteShort(this BinaryWriter @this, short value)
        {
            @this.Write(value);
        }
        public static void WriteChars(this BinaryWriter @this, char[] chars, int index, int count)
        {
            @this.Write(chars, index, count);
        }
        public static void WriteBuffer(this BinaryWriter @this, byte[] buffer, int index, int count)
        {
            @this.Write(buffer, index, count);
        }
    }
}
