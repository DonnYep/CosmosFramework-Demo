﻿namespace Krypton
{
    public static class ObjectExts
    {
        public static T As<T>(this object @this) where T : class
        {
            return (T)@this;
        }
    }
}
