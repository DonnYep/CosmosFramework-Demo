﻿using Krypton.AsyncOperation;
using System;
namespace Krypton
{
    public class KryptonDriver : MonoSingleton<KryptonDriver>
    {
        Action fixedUpdate;
        Action update;
        Action lateUpdate;
        public event Action FixedUpdateHandler
        {
            add { fixedUpdate += value; }
            remove { fixedUpdate -= value; }
        }
        public event Action UpdateHandler
        {
            add { update += value; }
            remove { update -= value; }
        }
        public event Action LateUpdateHandler
        {
            add { lateUpdate += value; }
            remove { lateUpdate -= value; }
        }
        private void FixedUpdate()
        {
            fixedUpdate?.Invoke();
        }
        private void Update()
        {
            AsyncOperationMonitor.Update();
            update?.Invoke();
        }
        private void LateUpdate()
        {
            lateUpdate?.Invoke();
        }
        void Awake()
        {
            gameObject.name = "KryptonDriver";
            DontDestroyOnLoad(this.gameObject);
        }
    }
}
